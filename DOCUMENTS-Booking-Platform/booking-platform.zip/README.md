# Booking Platform - Local Service Marketplace

## COMP313 - Team 6

A full-stack web application for booking local services. Customers post service requests, providers submit competitive bids, and bookings are managed through an intuitive dashboard.

## Features

### Customer Features
- Register and login as a customer
- Post service requests (haircut, cleaning, plumbing, etc.)
- Receive and compare bids from providers
- Accept bids to create bookings
- Rate and review completed services
- View booking history and status

### Provider Features
- Register and login as a service provider
- Browse open service requests
- Submit competitive bids with pricing
- Manage availability calendar
- Track bookings and earnings
- View customer ratings

### Admin Features
- Platform statistics dashboard
- User management (view, suspend, delete)
- Booking oversight
- Review moderation

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 19, Vite, TailwindCSS v4, React Router v7 |
| Backend | Node.js, Express.js |
| Database | MongoDB with Mongoose ODM |
| Authentication | JWT (JSON Web Tokens) |
| Validation | express-validator |

## Quick Start

### Prerequisites
- Node.js v18+
- MongoDB (local or Atlas)

### 1. Clone and Install

```bash
# Install backend dependencies
cd backend
npm install

# Install frontend dependencies
cd ../frontend
npm install
```

### 2. Configure Environment

Create `backend/.env`:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/booking_platform
JWT_SECRET=your_jwt_secret_key_here
JWT_EXPIRES_IN=7d
NODE_ENV=development
CLIENT_URL=http://localhost:5173
```

### 3. Seed Database (Optional)

```bash
cd backend
node seed.js
```

### 4. Start the Application

```bash
# Terminal 1: Start backend
cd backend
npm run dev

# Terminal 2: Start frontend
cd frontend
npm run dev
```

### 5. Access the Application
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000/api

## Test Accounts (after seeding)

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@booking.com | admin123 |
| Provider | john@booking.com | provider123 |
| Provider | sarah@booking.com | provider123 |
| Provider | mike@booking.com | provider123 |
| Customer | alice@booking.com | customer123 |
| Customer | bob@booking.com | customer123 |

## API Documentation

See [backend/README.md](./backend/README.md) for full API endpoint documentation.

## Project Structure

```
booking-platform/
├── backend/
│   ├── src/
│   │   ├── config/       # Database and environment config
│   │   ├── models/       # Mongoose models
│   │   ├── controllers/  # Route handlers
│   │   ├── routes/       # Express routes
│   │   ├── middleware/    # Auth, role, error middleware
│   │   ├── utils/        # Validators
│   │   └── app.js        # Express app setup
│   ├── server.js         # Server entry point
│   ├── seed.js           # Database seeder
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── api/          # API functions
│   │   ├── app/          # Main App with routes
│   │   ├── auth/         # Auth context and guards
│   │   ├── components/   # Reusable components
│   │   ├── hooks/        # Custom hooks
│   │   ├── layouts/      # Layout wrappers
│   │   └── pages/        # Page components
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
└── README.md
```

## Methodology
- **Agile Scrum** with 2-week sprints
- **CI/CD** with GitHub Actions
- **Version Control** with Git/GitHub

## Team Members - Group 6
COMP313 - Software Development Project 2
