/**
 * @module server
 * @description Entry point for the Booking Platform backend server.
 * Connects to MongoDB and starts the Express HTTP server.
 */

const app = require('./src/app');
const connectDB = require('./src/config/db');
const { PORT, NODE_ENV } = require('./src/config/env');

/**
 * Starts the server by connecting to the database and listening on the configured port.
 * @async
 * @function startServer
 */
const startServer = async () => {
  try {
    /* Establish database connection. */
    await connectDB();

    /* Start the HTTP server. */
    app.listen(PORT, () => {
      console.log(`Server running in ${NODE_ENV} mode on port ${PORT}`);
      console.log(`API available at http://localhost:${PORT}/api`);
    });
  } catch (error) {
    console.error('Failed to start server:', error.message);
    process.exit(1);
  }
};

startServer();
