/**
 * @module seed
 * @description Database seeding script for development and testing.
 * Creates sample users (admin, providers, customers) and service requests.
 * Run with: node seed.js
 */

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const connectDB = require('./src/config/db');
const User = require('./src/models/User.model');
const Service = require('./src/models/Service.model');
const Booking = require('./src/models/Booking.model');
const Availability = require('./src/models/Availability.model');

const seedData = async () => {
  try {
    await connectDB();

    /* Clear existing data. */
    await User.deleteMany({});
    await Service.deleteMany({});
    await Booking.deleteMany({});
    await Availability.deleteMany({});

    console.log('Cleared existing data.');

    /* Create admin user. */
    const admin = await User.create({
      name: 'Admin User',
      email: 'admin@booking.com',
      password: 'admin123',
      role: 'admin'
    });

    /* Create provider users. */
    const provider1 = await User.create({
      name: 'John Barber',
      email: 'john@booking.com',
      password: 'provider123',
      role: 'provider',
      phone: '416-555-0101',
      bio: 'Professional barber with 10 years of experience in modern and classic haircuts.',
      serviceTypes: ['haircut']
    });

    const provider2 = await User.create({
      name: 'Sarah Cleaner',
      email: 'sarah@booking.com',
      password: 'provider123',
      role: 'provider',
      phone: '416-555-0102',
      bio: 'Certified cleaning professional offering residential and commercial cleaning services.',
      serviceTypes: ['cleaning']
    });

    const provider3 = await User.create({
      name: 'Mike Plumber',
      email: 'mike@booking.com',
      password: 'provider123',
      role: 'provider',
      phone: '416-555-0103',
      bio: 'Licensed plumber specializing in residential plumbing repairs and installations.',
      serviceTypes: ['plumbing']
    });

    /* Create customer users. */
    const customer1 = await User.create({
      name: 'Alice Customer',
      email: 'alice@booking.com',
      password: 'customer123',
      role: 'customer',
      phone: '416-555-0201'
    });

    const customer2 = await User.create({
      name: 'Bob Customer',
      email: 'bob@booking.com',
      password: 'customer123',
      role: 'customer',
      phone: '416-555-0202'
    });

    console.log('Created users.');

    /* Create sample service requests. */
    const service1 = await Service.create({
      customer: customer1._id,
      title: 'Need a Haircut at Home',
      serviceType: 'haircut',
      description: 'Looking for a professional barber to come to my home for a modern fade haircut. I prefer someone with experience in mens hairstyles.',
      location: '123 Main Street, Toronto, ON',
      preferredTime: new Date('2026-03-01T10:00:00'),
      status: 'open'
    });

    const service2 = await Service.create({
      customer: customer1._id,
      title: 'Deep House Cleaning',
      serviceType: 'cleaning',
      description: 'Need a thorough deep cleaning of my 3-bedroom apartment including kitchen, bathrooms, and all living areas. Must bring own supplies.',
      location: '456 Queen Street, Toronto, ON',
      preferredTime: new Date('2026-03-05T09:00:00'),
      status: 'open'
    });

    const service3 = await Service.create({
      customer: customer2._id,
      title: 'Fix Leaking Kitchen Faucet',
      serviceType: 'plumbing',
      description: 'My kitchen faucet has been leaking for a week. Need a plumber to diagnose and fix the issue. The faucet is a standard single-handle model.',
      location: '789 King Street, Toronto, ON',
      preferredTime: new Date('2026-03-03T14:00:00'),
      status: 'open'
    });

    const service4 = await Service.create({
      customer: customer2._id,
      title: 'Math Tutoring for High School',
      serviceType: 'tutoring',
      description: 'Looking for a math tutor for my child in Grade 11. Need help with advanced functions and calculus preparation. Weekly sessions preferred.',
      location: '321 College Street, Toronto, ON',
      preferredTime: new Date('2026-03-10T16:00:00'),
      status: 'open'
    });

    console.log('Created service requests.');

    /* Add sample bids to service1. */
    service1.bids.push({
      provider: provider1._id,
      price: 45,
      message: 'I can do a great fade haircut. 10 years of experience!'
    });
    await service1.save();

    /* Add sample bids to service2. */
    service2.bids.push({
      provider: provider2._id,
      price: 150,
      message: 'I offer thorough deep cleaning with eco-friendly products. 3-bedroom apartment typically takes 4-5 hours.'
    });
    await service2.save();

    /* Add sample bids to service3. */
    service3.bids.push({
      provider: provider3._id,
      price: 80,
      message: 'I can fix your leaking faucet. Most faucet repairs take about 1 hour.'
    });
    await service3.save();

    console.log('Added sample bids.');

    /* Create provider availability slots. */
    const today = new Date();
    for (let i = 1; i <= 7; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() + i);

      await Availability.create({
        provider: provider1._id,
        date,
        startTime: '09:00',
        endTime: '12:00'
      });

      await Availability.create({
        provider: provider1._id,
        date,
        startTime: '13:00',
        endTime: '17:00'
      });

      await Availability.create({
        provider: provider2._id,
        date,
        startTime: '08:00',
        endTime: '16:00'
      });

      await Availability.create({
        provider: provider3._id,
        date,
        startTime: '10:00',
        endTime: '18:00'
      });
    }

    console.log('Created availability slots.');

    console.log('\n===== Seed Data Summary =====');
    console.log('Admin:    admin@booking.com / admin123');
    console.log('Provider: john@booking.com / provider123');
    console.log('Provider: sarah@booking.com / provider123');
    console.log('Provider: mike@booking.com / provider123');
    console.log('Customer: alice@booking.com / customer123');
    console.log('Customer: bob@booking.com / customer123');
    console.log('=============================\n');

    process.exit(0);
  } catch (error) {
    console.error('Seeding error:', error);
    process.exit(1);
  }
};

seedData();
