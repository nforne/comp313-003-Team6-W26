/**
 * @module app
 * @description Express application configuration.
 * Sets up middleware, routes, and error handling for the Booking Platform API.
 */

const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const morgan = require('morgan');
const { CLIENT_URL, NODE_ENV } = require('./config/env');
const { globalErrorHandler } = require('./middleware/error.middleware');

/* Import route modules. */
const authRoutes = require('./routes/auth.routes');
const servicesRoutes = require('./routes/services.routes');
const availabilityRoutes = require('./routes/availability.routes');
const bookingsRoutes = require('./routes/bookings.routes');
const adminRoutes = require('./routes/admin.routes');

const app = express();

/* ===== Global Middleware ===== */

/** Parse JSON request bodies. */
app.use(express.json());

/** Parse URL-encoded request bodies. */
app.use(express.urlencoded({ extended: true }));

/** Parse cookies. */
app.use(cookieParser());

/** Enable CORS for the frontend client. */
app.use(
  cors({
    origin: CLIENT_URL,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization']
  })
);

/** HTTP request logging (disabled in test environment). */
if (NODE_ENV !== 'test') {
  app.use(morgan('dev'));
}

/* ===== API Routes ===== */

/** Health check endpoint. */
app.get('/api/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Booking Platform API is running.',
    timestamp: new Date().toISOString()
  });
});

/** Authentication routes. */
app.use('/api/auth', authRoutes);

/** Service request routes. */
app.use('/api/services', servicesRoutes);

/** Availability management routes. */
app.use('/api/availability', availabilityRoutes);

/** Booking management routes. */
app.use('/api/bookings', bookingsRoutes);

/** Admin routes. */
app.use('/api/admin', adminRoutes);

/* ===== 404 Handler ===== */
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.originalUrl}`
  });
});

/* ===== Global Error Handler ===== */
app.use(globalErrorHandler);

module.exports = app;
