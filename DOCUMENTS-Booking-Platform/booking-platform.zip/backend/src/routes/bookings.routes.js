/**
 * @module routes/bookings
 * @description Express router for booking management endpoints.
 * Includes creating bookings, updating status, and submitting ratings.
 */

const express = require('express');
const router = express.Router();
const {
  createBooking,
  getMyBookings,
  getBookingById,
  updateBookingStatus,
  submitRating
} = require('../controllers/bookings.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { checkRole } = require('../middleware/role.middleware');
const { handleValidationErrors } = require('../middleware/error.middleware');
const { createBookingValidation, ratingValidation } = require('../utils/validators');

/**
 * @route   GET /api/bookings
 * @desc    Get all bookings for the current user
 * @access  Private
 */
router.get('/', verifyToken, getMyBookings);

/**
 * @route   GET /api/bookings/:id
 * @desc    Get a single booking by ID
 * @access  Private
 */
router.get('/:id', verifyToken, getBookingById);

/**
 * @route   POST /api/bookings
 * @desc    Create a booking by accepting a bid
 * @access  Private (Customer)
 */
router.post(
  '/',
  verifyToken,
  checkRole('customer'),
  createBookingValidation,
  handleValidationErrors,
  createBooking
);

/**
 * @route   PUT /api/bookings/:id/status
 * @desc    Update booking status (confirm, complete, cancel)
 * @access  Private
 */
router.put('/:id/status', verifyToken, updateBookingStatus);

/**
 * @route   POST /api/bookings/:id/rating
 * @desc    Submit a rating for a completed booking
 * @access  Private (Customer)
 */
router.post(
  '/:id/rating',
  verifyToken,
  checkRole('customer'),
  ratingValidation,
  handleValidationErrors,
  submitRating
);

module.exports = router;
