/**
 * @module routes/services
 * @description Express router for service request endpoints.
 * Includes CRUD operations for service requests and bid management.
 */

const express = require('express');
const router = express.Router();
const {
  getAllServices,
  getServiceById,
  createService,
  updateService,
  deleteService,
  submitBid,
  getMyServices,
  getMyBids
} = require('../controllers/services.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { checkRole } = require('../middleware/role.middleware');
const { handleValidationErrors } = require('../middleware/error.middleware');
const { createServiceValidation, submitBidValidation } = require('../utils/validators');

/**
 * @route   GET /api/services/my-requests
 * @desc    Get all service requests created by the current customer
 * @access  Private (Customer)
 */
router.get('/my-requests', verifyToken, checkRole('customer'), getMyServices);

/**
 * @route   GET /api/services/my-bids
 * @desc    Get all service requests where the current provider has bids
 * @access  Private (Provider)
 */
router.get('/my-bids', verifyToken, checkRole('provider'), getMyBids);

/**
 * @route   GET /api/services
 * @desc    Get all open service requests
 * @access  Public
 */
router.get('/', getAllServices);

/**
 * @route   GET /api/services/:id
 * @desc    Get a single service request by ID
 * @access  Public
 */
router.get('/:id', getServiceById);

/**
 * @route   POST /api/services
 * @desc    Create a new service request
 * @access  Private (Customer)
 */
router.post(
  '/',
  verifyToken,
  checkRole('customer'),
  createServiceValidation,
  handleValidationErrors,
  createService
);

/**
 * @route   PUT /api/services/:id
 * @desc    Update a service request
 * @access  Private (Customer - owner)
 */
router.put('/:id', verifyToken, checkRole('customer'), updateService);

/**
 * @route   DELETE /api/services/:id
 * @desc    Cancel a service request
 * @access  Private (Customer - owner, Admin)
 */
router.delete('/:id', verifyToken, deleteService);

/**
 * @route   POST /api/services/:id/bids
 * @desc    Submit a bid on a service request
 * @access  Private (Provider)
 */
router.post(
  '/:id/bids',
  verifyToken,
  checkRole('provider'),
  submitBidValidation,
  handleValidationErrors,
  submitBid
);

module.exports = router;
