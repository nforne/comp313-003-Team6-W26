/**
 * @module routes/admin
 * @description Express router for admin-specific endpoints.
 * Includes user management, booking oversight, review moderation, and statistics.
 */

const express = require('express');
const router = express.Router();
const {
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  getAllBookings,
  getAllReviews,
  deleteReview,
  getStats
} = require('../controllers/admin.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { checkRole } = require('../middleware/role.middleware');

/* All admin routes require authentication and admin role. */
router.use(verifyToken, checkRole('admin'));

/**
 * @route   GET /api/admin/stats
 * @desc    Get platform statistics
 * @access  Private (Admin)
 */
router.get('/stats', getStats);

/**
 * @route   GET /api/admin/users
 * @desc    Get all users
 * @access  Private (Admin)
 */
router.get('/users', getAllUsers);

/**
 * @route   GET /api/admin/users/:id
 * @desc    Get a single user by ID
 * @access  Private (Admin)
 */
router.get('/users/:id', getUserById);

/**
 * @route   PUT /api/admin/users/:id
 * @desc    Update user status or role
 * @access  Private (Admin)
 */
router.put('/users/:id', updateUser);

/**
 * @route   DELETE /api/admin/users/:id
 * @desc    Delete a user
 * @access  Private (Admin)
 */
router.delete('/users/:id', deleteUser);

/**
 * @route   GET /api/admin/bookings
 * @desc    Get all bookings
 * @access  Private (Admin)
 */
router.get('/bookings', getAllBookings);

/**
 * @route   GET /api/admin/reviews
 * @desc    Get all reviews for moderation
 * @access  Private (Admin)
 */
router.get('/reviews', getAllReviews);

/**
 * @route   DELETE /api/admin/reviews/:bookingId
 * @desc    Delete a review (moderation)
 * @access  Private (Admin)
 */
router.delete('/reviews/:bookingId', deleteReview);

module.exports = router;
