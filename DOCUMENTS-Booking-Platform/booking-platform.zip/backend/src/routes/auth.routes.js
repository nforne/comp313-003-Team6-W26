/**
 * @module routes/auth
 * @description Express router for authentication-related endpoints.
 * Includes registration, login, logout, and profile management.
 */

const express = require('express');
const router = express.Router();
const { register, login, logout, getMe, updateProfile } = require('../controllers/auth.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { handleValidationErrors } = require('../middleware/error.middleware');
const { registerValidation, loginValidation } = require('../utils/validators');

/**
 * @route   POST /api/auth/register
 * @desc    Register a new user account
 * @access  Public
 */
router.post('/register', registerValidation, handleValidationErrors, register);

/**
 * @route   POST /api/auth/login
 * @desc    Authenticate user and return JWT token
 * @access  Public
 */
router.post('/login', loginValidation, handleValidationErrors, login);

/**
 * @route   POST /api/auth/logout
 * @desc    Logout user (client-side token removal)
 * @access  Private
 */
router.post('/logout', verifyToken, logout);

/**
 * @route   GET /api/auth/me
 * @desc    Get current authenticated user's profile
 * @access  Private
 */
router.get('/me', verifyToken, getMe);

/**
 * @route   PUT /api/auth/me
 * @desc    Update current authenticated user's profile
 * @access  Private
 */
router.put('/me', verifyToken, updateProfile);

module.exports = router;
