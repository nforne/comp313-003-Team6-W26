/**
 * @module routes/availability
 * @description Express router for provider availability management endpoints.
 * Includes CRUD operations for availability time slots.
 */

const express = require('express');
const router = express.Router();
const {
  getProviderAvailability,
  getMyAvailability,
  createAvailability,
  updateAvailability,
  deleteAvailability
} = require('../controllers/availability.controller');
const { verifyToken } = require('../middleware/auth.middleware');
const { checkRole } = require('../middleware/role.middleware');
const { handleValidationErrors } = require('../middleware/error.middleware');
const { availabilityValidation } = require('../utils/validators');

/**
 * @route   GET /api/availability
 * @desc    Get current provider's own availability slots
 * @access  Private (Provider)
 */
router.get('/', verifyToken, checkRole('provider'), getMyAvailability);

/**
 * @route   GET /api/availability/provider/:providerId
 * @desc    Get availability slots for a specific provider
 * @access  Public
 */
router.get('/provider/:providerId', getProviderAvailability);

/**
 * @route   POST /api/availability
 * @desc    Create a new availability slot
 * @access  Private (Provider)
 */
router.post(
  '/',
  verifyToken,
  checkRole('provider'),
  availabilityValidation,
  handleValidationErrors,
  createAvailability
);

/**
 * @route   PUT /api/availability/:id
 * @desc    Update an availability slot
 * @access  Private (Provider - owner)
 */
router.put('/:id', verifyToken, checkRole('provider'), updateAvailability);

/**
 * @route   DELETE /api/availability/:id
 * @desc    Delete an availability slot
 * @access  Private (Provider - owner)
 */
router.delete('/:id', verifyToken, checkRole('provider'), deleteAvailability);

module.exports = router;
