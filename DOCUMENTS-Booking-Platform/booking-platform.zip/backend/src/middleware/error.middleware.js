/**
 * @module middleware/error
 * @description Global error handling middleware for the Express application.
 * Catches all errors thrown in routes and middleware, formats them consistently,
 * and sends an appropriate HTTP response.
 */

const { validationResult } = require('express-validator');

/**
 * Middleware to handle express-validator validation errors.
 * Should be placed after validation chains in route definitions.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @param {Function} next - Express next middleware function.
 */
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array().map((err) => ({
        field: err.path,
        message: err.msg
      }))
    });
  }
  next();
};

/**
 * Global error handler middleware.
 * Catches unhandled errors and returns a formatted JSON response.
 * @param {Error} err - The error object.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @param {Function} next - Express next middleware function.
 */
const globalErrorHandler = (err, req, res, next) => {
  console.error('Error:', err.message);

  /* Handle Mongoose validation errors. */
  if (err.name === 'ValidationError') {
    const messages = Object.values(err.errors).map((e) => e.message);
    return res.status(400).json({
      success: false,
      message: 'Validation Error',
      errors: messages
    });
  }

  /* Handle Mongoose duplicate key errors. */
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue)[0];
    return res.status(409).json({
      success: false,
      message: `Duplicate value for field: ${field}. This ${field} is already in use.`
    });
  }

  /* Handle Mongoose cast errors (invalid ObjectId). */
  if (err.name === 'CastError') {
    return res.status(400).json({
      success: false,
      message: `Invalid ${err.path}: ${err.value}`
    });
  }

  /* Default server error response. */
  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    success: false,
    message: err.message || 'Internal Server Error'
  });
};

module.exports = { handleValidationErrors, globalErrorHandler };
