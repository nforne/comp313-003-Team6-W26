/**
 * @module middleware/auth
 * @description JWT authentication middleware.
 * Verifies the JSON Web Token from the Authorization header or cookies
 * and attaches the decoded user information to the request object.
 */

const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../config/env');
const User = require('../models/User.model');

/**
 * Middleware to verify JWT and authenticate the user.
 * Checks for token in Authorization header (Bearer scheme) or cookies.
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @param {Function} next - Express next middleware function.
 */
const verifyToken = async (req, res, next) => {
  try {
    let token;

    /* Extract token from Authorization header or cookie. */
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith('Bearer')
    ) {
      token = req.headers.authorization.split(' ')[1];
    } else if (req.cookies && req.cookies.token) {
      token = req.cookies.token;
    }

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Access denied. No token provided.'
      });
    }

    /* Verify the token and decode the payload. */
    const decoded = jwt.verify(token, JWT_SECRET);

    /* Find the user associated with the token. */
    const user = await User.findById(decoded.id);
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'User associated with this token no longer exists.'
      });
    }

    if (!user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'User account has been deactivated.'
      });
    }

    /* Attach user to request object for downstream middleware and routes. */
    req.user = user;
    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        message: 'Invalid token.'
      });
    }
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Token has expired.'
      });
    }
    return res.status(500).json({
      success: false,
      message: 'Internal server error during authentication.'
    });
  }
};

module.exports = { verifyToken };
