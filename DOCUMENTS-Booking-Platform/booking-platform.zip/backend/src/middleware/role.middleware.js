/**
 * @module middleware/role
 * @description Role-based access control middleware.
 * Restricts route access to users with specific roles (admin, provider, customer).
 * Must be used after the auth middleware (verifyToken).
 */

/**
 * Creates a middleware that restricts access to users with the specified roles.
 * @param {...string} roles - Allowed roles (e.g., 'admin', 'provider', 'customer').
 * @returns {Function} Express middleware function.
 *
 * @example
 * // Allow only admins
 * router.get('/admin-only', verifyToken, checkRole('admin'), handler);
 *
 * // Allow providers and admins
 * router.get('/providers', verifyToken, checkRole('provider', 'admin'), handler);
 */
const checkRole = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required.'
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Access denied. Required role(s): ${roles.join(', ')}.`
      });
    }

    next();
  };
};

module.exports = { checkRole };
