/**
 * @module controllers/services
 * @description Controller for service request management.
 * Handles creating, reading, updating service requests, and managing bids.
 */

const Service = require('../models/Service.model');

/**
 * @desc    Get all open service requests (for providers to browse)
 * @route   GET /api/services
 * @access  Public
 */
const getAllServices = async (req, res, next) => {
  try {
    const { serviceType, status, page = 1, limit = 10 } = req.query;
    const filter = {};

    if (serviceType) filter.serviceType = serviceType;
    if (status) filter.status = status;
    else filter.status = 'open';

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await Service.countDocuments(filter);

    const services = await Service.find(filter)
      .populate('customer', 'name email')
      .populate('bids.provider', 'name email bio serviceTypes')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    res.status(200).json({
      success: true,
      data: {
        services,
        pagination: {
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get a single service request by ID
 * @route   GET /api/services/:id
 * @access  Public
 */
const getServiceById = async (req, res, next) => {
  try {
    const service = await Service.findById(req.params.id)
      .populate('customer', 'name email phone')
      .populate('bids.provider', 'name email bio serviceTypes phone')
      .populate('selectedProvider', 'name email phone');

    if (!service) {
      return res.status(404).json({
        success: false,
        message: 'Service request not found.'
      });
    }

    res.status(200).json({
      success: true,
      data: { service }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Create a new service request
 * @route   POST /api/services
 * @access  Private (Customer)
 */
const createService = async (req, res, next) => {
  try {
    const { title, serviceType, description, location, preferredTime } = req.body;

    const service = await Service.create({
      customer: req.user._id,
      title,
      serviceType,
      description,
      location,
      preferredTime
    });

    const populatedService = await Service.findById(service._id)
      .populate('customer', 'name email');

    res.status(201).json({
      success: true,
      message: 'Service request created successfully.',
      data: { service: populatedService }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Update a service request (only by the customer who created it)
 * @route   PUT /api/services/:id
 * @access  Private (Customer - owner)
 */
const updateService = async (req, res, next) => {
  try {
    const service = await Service.findById(req.params.id);

    if (!service) {
      return res.status(404).json({
        success: false,
        message: 'Service request not found.'
      });
    }

    /* Ensure only the owner can update the service request. */
    if (service.customer.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'You are not authorized to update this service request.'
      });
    }

    /* Only allow updates when the service is still open. */
    if (service.status !== 'open') {
      return res.status(400).json({
        success: false,
        message: 'Cannot update a service request that is no longer open.'
      });
    }

    const allowedFields = ['title', 'serviceType', 'description', 'location', 'preferredTime'];
    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        service[field] = req.body[field];
      }
    });

    await service.save();

    const updatedService = await Service.findById(service._id)
      .populate('customer', 'name email');

    res.status(200).json({
      success: true,
      message: 'Service request updated successfully.',
      data: { service: updatedService }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Delete (cancel) a service request
 * @route   DELETE /api/services/:id
 * @access  Private (Customer - owner, or Admin)
 */
const deleteService = async (req, res, next) => {
  try {
    const service = await Service.findById(req.params.id);

    if (!service) {
      return res.status(404).json({
        success: false,
        message: 'Service request not found.'
      });
    }

    /* Allow deletion by the owner or an admin. */
    const isOwner = service.customer.toString() === req.user._id.toString();
    const isAdmin = req.user.role === 'admin';

    if (!isOwner && !isAdmin) {
      return res.status(403).json({
        success: false,
        message: 'You are not authorized to delete this service request.'
      });
    }

    service.status = 'cancelled';
    await service.save();

    res.status(200).json({
      success: true,
      message: 'Service request cancelled successfully.'
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Submit a bid on a service request
 * @route   POST /api/services/:id/bids
 * @access  Private (Provider)
 */
const submitBid = async (req, res, next) => {
  try {
    const service = await Service.findById(req.params.id);

    if (!service) {
      return res.status(404).json({
        success: false,
        message: 'Service request not found.'
      });
    }

    if (service.status !== 'open') {
      return res.status(400).json({
        success: false,
        message: 'Cannot bid on a service request that is not open.'
      });
    }

    /* Check if provider has already bid on this service. */
    const existingBid = service.bids.find(
      (bid) => bid.provider.toString() === req.user._id.toString()
    );

    if (existingBid) {
      return res.status(400).json({
        success: false,
        message: 'You have already submitted a bid for this service request.'
      });
    }

    const { price, message } = req.body;

    service.bids.push({
      provider: req.user._id,
      price,
      message: message || ''
    });

    await service.save();

    const updatedService = await Service.findById(service._id)
      .populate('customer', 'name email')
      .populate('bids.provider', 'name email bio serviceTypes');

    res.status(201).json({
      success: true,
      message: 'Bid submitted successfully.',
      data: { service: updatedService }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get all service requests created by the current customer
 * @route   GET /api/services/my-requests
 * @access  Private (Customer)
 */
const getMyServices = async (req, res, next) => {
  try {
    const services = await Service.find({ customer: req.user._id })
      .populate('bids.provider', 'name email bio serviceTypes')
      .populate('selectedProvider', 'name email')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: { services }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get all service requests where the current provider has submitted bids
 * @route   GET /api/services/my-bids
 * @access  Private (Provider)
 */
const getMyBids = async (req, res, next) => {
  try {
    const services = await Service.find({
      'bids.provider': req.user._id
    })
      .populate('customer', 'name email')
      .populate('bids.provider', 'name email bio serviceTypes')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: { services }
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getAllServices,
  getServiceById,
  createService,
  updateService,
  deleteService,
  submitBid,
  getMyServices,
  getMyBids
};
