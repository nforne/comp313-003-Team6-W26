/**
 * @module controllers/bookings
 * @description Controller for booking management.
 * Handles creating bookings (confirming bids), updating booking status,
 * retrieving bookings, and submitting ratings/reviews.
 */

const Booking = require('../models/Booking.model');
const Service = require('../models/Service.model');
const Availability = require('../models/Availability.model');

/**
 * @desc    Create a booking by accepting a bid on a service request
 * @route   POST /api/bookings
 * @access  Private (Customer)
 */
const createBooking = async (req, res, next) => {
  try {
    const { serviceId, bidId } = req.body;

    /* Find the service request. */
    const service = await Service.findById(serviceId);
    if (!service) {
      return res.status(404).json({
        success: false,
        message: 'Service request not found.'
      });
    }

    /* Verify the customer owns this service request. */
    if (service.customer.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'You can only confirm bookings for your own service requests.'
      });
    }

    /* Ensure the service is still open. */
    if (service.status !== 'open') {
      return res.status(400).json({
        success: false,
        message: 'This service request is no longer open for booking.'
      });
    }

    /* Find the selected bid. */
    const bid = service.bids.id(bidId);
    if (!bid) {
      return res.status(404).json({
        success: false,
        message: 'Bid not found on this service request.'
      });
    }

    /* Check for scheduling conflicts (prevent double bookings). */
    const conflictingBooking = await Booking.findOne({
      provider: bid.provider,
      scheduledTime: service.preferredTime,
      status: { $in: ['pending', 'confirmed'] }
    });

    if (conflictingBooking) {
      return res.status(409).json({
        success: false,
        message: 'The provider has a scheduling conflict at the requested time.'
      });
    }

    /* Create the booking. */
    const booking = await Booking.create({
      service: service._id,
      customer: req.user._id,
      provider: bid.provider,
      scheduledTime: service.preferredTime,
      price: bid.price,
      status: 'confirmed'
    });

    /* Update the service request status and selected provider. */
    service.status = 'in_progress';
    service.selectedProvider = bid.provider;
    service.selectedBidPrice = bid.price;
    await service.save();

    /* Block the provider's calendar for this time slot. */
    const scheduledDate = new Date(service.preferredTime);
    const startHour = scheduledDate.getHours().toString().padStart(2, '0');
    const startMin = scheduledDate.getMinutes().toString().padStart(2, '0');
    const endHour = Math.min(scheduledDate.getHours() + 1, 23).toString().padStart(2, '0');

    await Availability.create({
      provider: bid.provider,
      date: scheduledDate,
      startTime: `${startHour}:${startMin}`,
      endTime: `${endHour}:${startMin}`,
      isBlocked: true,
      bookingRef: booking._id
    });

    const populatedBooking = await Booking.findById(booking._id)
      .populate('service', 'title serviceType location')
      .populate('customer', 'name email')
      .populate('provider', 'name email phone');

    res.status(201).json({
      success: true,
      message: 'Booking confirmed successfully. Provider calendar has been updated.',
      data: { booking: populatedBooking }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get all bookings for the current user (customer or provider)
 * @route   GET /api/bookings
 * @access  Private
 */
const getMyBookings = async (req, res, next) => {
  try {
    const { status, page = 1, limit = 10 } = req.query;
    const filter = {};

    /* Filter by user role. */
    if (req.user.role === 'customer') {
      filter.customer = req.user._id;
    } else if (req.user.role === 'provider') {
      filter.provider = req.user._id;
    }

    if (status) filter.status = status;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await Booking.countDocuments(filter);

    const bookings = await Booking.find(filter)
      .populate('service', 'title serviceType location preferredTime description')
      .populate('customer', 'name email')
      .populate('provider', 'name email phone bio')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    res.status(200).json({
      success: true,
      data: {
        bookings,
        pagination: {
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get a single booking by ID
 * @route   GET /api/bookings/:id
 * @access  Private
 */
const getBookingById = async (req, res, next) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate('service', 'title serviceType location preferredTime description bids')
      .populate('customer', 'name email phone')
      .populate('provider', 'name email phone bio serviceTypes');

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found.'
      });
    }

    /* Ensure the user is involved in this booking or is an admin. */
    const isCustomer = booking.customer._id.toString() === req.user._id.toString();
    const isProvider = booking.provider._id.toString() === req.user._id.toString();
    const isAdmin = req.user.role === 'admin';

    if (!isCustomer && !isProvider && !isAdmin) {
      return res.status(403).json({
        success: false,
        message: 'You are not authorized to view this booking.'
      });
    }

    res.status(200).json({
      success: true,
      data: { booking }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Update booking status (confirm, complete, cancel)
 * @route   PUT /api/bookings/:id/status
 * @access  Private
 */
const updateBookingStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    const booking = await Booking.findById(req.params.id);

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found.'
      });
    }

    /* Validate status transitions. */
    const validTransitions = {
      pending: ['confirmed', 'cancelled'],
      confirmed: ['completed', 'cancelled'],
      completed: [],
      cancelled: []
    };

    if (!validTransitions[booking.status].includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Cannot transition from '${booking.status}' to '${status}'.`
      });
    }

    /* Authorization checks based on status change. */
    const isCustomer = booking.customer.toString() === req.user._id.toString();
    const isProvider = booking.provider.toString() === req.user._id.toString();
    const isAdmin = req.user.role === 'admin';

    if (status === 'completed' && !isProvider && !isAdmin) {
      return res.status(403).json({
        success: false,
        message: 'Only the provider or admin can mark a booking as completed.'
      });
    }

    if (status === 'cancelled' && !isCustomer && !isProvider && !isAdmin) {
      return res.status(403).json({
        success: false,
        message: 'You are not authorized to cancel this booking.'
      });
    }

    booking.status = status;
    await booking.save();

    /* If cancelled, update the service status and unblock the calendar. */
    if (status === 'cancelled') {
      await Service.findByIdAndUpdate(booking.service, { status: 'open', selectedProvider: null, selectedBidPrice: null });
      await Availability.deleteMany({ bookingRef: booking._id });
    }

    /* If completed, update the service status. */
    if (status === 'completed') {
      await Service.findByIdAndUpdate(booking.service, { status: 'completed' });
    }

    const updatedBooking = await Booking.findById(booking._id)
      .populate('service', 'title serviceType location')
      .populate('customer', 'name email')
      .populate('provider', 'name email');

    res.status(200).json({
      success: true,
      message: `Booking status updated to '${status}'.`,
      data: { booking: updatedBooking }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Submit a rating and review for a completed booking
 * @route   POST /api/bookings/:id/rating
 * @access  Private (Customer)
 */
const submitRating = async (req, res, next) => {
  try {
    const booking = await Booking.findById(req.params.id);

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found.'
      });
    }

    /* Only the customer can rate the booking. */
    if (booking.customer.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Only the customer can rate this booking.'
      });
    }

    /* Only completed bookings can be rated. */
    if (booking.status !== 'completed') {
      return res.status(400).json({
        success: false,
        message: 'Can only rate completed bookings.'
      });
    }

    /* Prevent duplicate ratings. */
    if (booking.rating) {
      return res.status(400).json({
        success: false,
        message: 'This booking has already been rated.'
      });
    }

    const { score, comment } = req.body;

    booking.rating = {
      score,
      comment: comment || ''
    };

    await booking.save();

    const updatedBooking = await Booking.findById(booking._id)
      .populate('service', 'title serviceType')
      .populate('customer', 'name email')
      .populate('provider', 'name email');

    res.status(200).json({
      success: true,
      message: 'Rating submitted successfully.',
      data: { booking: updatedBooking }
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createBooking,
  getMyBookings,
  getBookingById,
  updateBookingStatus,
  submitRating
};
