/**
 * @module controllers/admin
 * @description Controller for admin-specific operations.
 * Handles user management, booking oversight, rating moderation, and basic reporting.
 */

const User = require('../models/User.model');
const Service = require('../models/Service.model');
const Booking = require('../models/Booking.model');

/**
 * @desc    Get all users with optional role filter
 * @route   GET /api/admin/users
 * @access  Private (Admin)
 */
const getAllUsers = async (req, res, next) => {
  try {
    const { role, page = 1, limit = 20 } = req.query;
    const filter = {};

    if (role) filter.role = role;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await User.countDocuments(filter);

    const users = await User.find(filter)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    res.status(200).json({
      success: true,
      data: {
        users,
        pagination: {
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get a single user by ID
 * @route   GET /api/admin/users/:id
 * @access  Private (Admin)
 */
const getUserById = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found.'
      });
    }

    res.status(200).json({
      success: true,
      data: { user }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Update user status (activate/deactivate) or role
 * @route   PUT /api/admin/users/:id
 * @access  Private (Admin)
 */
const updateUser = async (req, res, next) => {
  try {
    const { isActive, role } = req.body;
    const updates = {};

    if (isActive !== undefined) updates.isActive = isActive;
    if (role) updates.role = role;

    const user = await User.findByIdAndUpdate(req.params.id, updates, {
      new: true,
      runValidators: true
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found.'
      });
    }

    res.status(200).json({
      success: true,
      message: 'User updated successfully.',
      data: { user }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Delete a user
 * @route   DELETE /api/admin/users/:id
 * @access  Private (Admin)
 */
const deleteUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found.'
      });
    }

    /* Prevent deleting admin accounts. */
    if (user.role === 'admin') {
      return res.status(400).json({
        success: false,
        message: 'Cannot delete admin accounts.'
      });
    }

    await User.findByIdAndDelete(req.params.id);

    res.status(200).json({
      success: true,
      message: 'User deleted successfully.'
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get all bookings (admin overview)
 * @route   GET /api/admin/bookings
 * @access  Private (Admin)
 */
const getAllBookings = async (req, res, next) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const filter = {};

    if (status) filter.status = status;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await Booking.countDocuments(filter);

    const bookings = await Booking.find(filter)
      .populate('service', 'title serviceType location')
      .populate('customer', 'name email')
      .populate('provider', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    res.status(200).json({
      success: true,
      data: {
        bookings,
        pagination: {
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get all ratings/reviews for moderation
 * @route   GET /api/admin/reviews
 * @access  Private (Admin)
 */
const getAllReviews = async (req, res, next) => {
  try {
    const bookingsWithRatings = await Booking.find({
      rating: { $ne: null }
    })
      .populate('service', 'title serviceType')
      .populate('customer', 'name email')
      .populate('provider', 'name email')
      .sort({ 'rating.createdAt': -1 });

    const reviews = bookingsWithRatings.map((booking) => ({
      bookingId: booking._id,
      service: booking.service,
      customer: booking.customer,
      provider: booking.provider,
      rating: booking.rating,
      bookingStatus: booking.status
    }));

    res.status(200).json({
      success: true,
      data: { reviews }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Delete a review (moderation)
 * @route   DELETE /api/admin/reviews/:bookingId
 * @access  Private (Admin)
 */
const deleteReview = async (req, res, next) => {
  try {
    const booking = await Booking.findById(req.params.bookingId);

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found.'
      });
    }

    if (!booking.rating) {
      return res.status(400).json({
        success: false,
        message: 'This booking does not have a review.'
      });
    }

    booking.rating = null;
    await booking.save();

    res.status(200).json({
      success: true,
      message: 'Review deleted successfully.'
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get platform statistics for admin dashboard
 * @route   GET /api/admin/stats
 * @access  Private (Admin)
 */
const getStats = async (req, res, next) => {
  try {
    const [
      totalUsers,
      totalCustomers,
      totalProviders,
      totalServices,
      openServices,
      totalBookings,
      completedBookings,
      cancelledBookings
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ role: 'customer' }),
      User.countDocuments({ role: 'provider' }),
      Service.countDocuments(),
      Service.countDocuments({ status: 'open' }),
      Booking.countDocuments(),
      Booking.countDocuments({ status: 'completed' }),
      Booking.countDocuments({ status: 'cancelled' })
    ]);

    res.status(200).json({
      success: true,
      data: {
        stats: {
          totalUsers,
          totalCustomers,
          totalProviders,
          totalServices,
          openServices,
          totalBookings,
          completedBookings,
          cancelledBookings
        }
      }
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  getAllBookings,
  getAllReviews,
  deleteReview,
  getStats
};
