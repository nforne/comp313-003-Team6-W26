/**
 * @module controllers/availability
 * @description Controller for managing provider availability time slots.
 * Handles creating, reading, updating, and deleting availability entries.
 */

const Availability = require('../models/Availability.model');

/**
 * @desc    Get availability slots for a specific provider
 * @route   GET /api/availability/:providerId
 * @access  Public
 */
const getProviderAvailability = async (req, res, next) => {
  try {
    const { providerId } = req.params;
    const { startDate, endDate } = req.query;

    const filter = { provider: providerId };

    /* Apply date range filter if provided. */
    if (startDate || endDate) {
      filter.date = {};
      if (startDate) filter.date.$gte = new Date(startDate);
      if (endDate) filter.date.$lte = new Date(endDate);
    }

    const availability = await Availability.find(filter)
      .populate('bookingRef', 'status scheduledTime')
      .sort({ date: 1, startTime: 1 });

    res.status(200).json({
      success: true,
      data: { availability }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get current provider's own availability
 * @route   GET /api/availability
 * @access  Private (Provider)
 */
const getMyAvailability = async (req, res, next) => {
  try {
    const availability = await Availability.find({ provider: req.user._id })
      .populate('bookingRef', 'status scheduledTime')
      .sort({ date: 1, startTime: 1 });

    res.status(200).json({
      success: true,
      data: { availability }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Create a new availability slot
 * @route   POST /api/availability
 * @access  Private (Provider)
 */
const createAvailability = async (req, res, next) => {
  try {
    const { date, startTime, endTime } = req.body;

    /* Validate that start time is before end time. */
    if (startTime >= endTime) {
      return res.status(400).json({
        success: false,
        message: 'Start time must be before end time.'
      });
    }

    /* Check for overlapping availability slots. */
    const overlapping = await Availability.findOne({
      provider: req.user._id,
      date: new Date(date),
      $or: [
        { startTime: { $lt: endTime }, endTime: { $gt: startTime } }
      ]
    });

    if (overlapping) {
      return res.status(400).json({
        success: false,
        message: 'This time slot overlaps with an existing availability entry.'
      });
    }

    const availability = await Availability.create({
      provider: req.user._id,
      date: new Date(date),
      startTime,
      endTime
    });

    res.status(201).json({
      success: true,
      message: 'Availability slot created successfully.',
      data: { availability }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Update an availability slot
 * @route   PUT /api/availability/:id
 * @access  Private (Provider - owner)
 */
const updateAvailability = async (req, res, next) => {
  try {
    const availability = await Availability.findById(req.params.id);

    if (!availability) {
      return res.status(404).json({
        success: false,
        message: 'Availability slot not found.'
      });
    }

    /* Ensure only the owner can update the slot. */
    if (availability.provider.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'You are not authorized to update this availability slot.'
      });
    }

    /* Blocked slots (linked to bookings) cannot be modified. */
    if (availability.isBlocked) {
      return res.status(400).json({
        success: false,
        message: 'Cannot modify a blocked availability slot linked to a booking.'
      });
    }

    const { date, startTime, endTime } = req.body;

    if (startTime && endTime && startTime >= endTime) {
      return res.status(400).json({
        success: false,
        message: 'Start time must be before end time.'
      });
    }

    if (date) availability.date = new Date(date);
    if (startTime) availability.startTime = startTime;
    if (endTime) availability.endTime = endTime;

    await availability.save();

    res.status(200).json({
      success: true,
      message: 'Availability slot updated successfully.',
      data: { availability }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Delete an availability slot
 * @route   DELETE /api/availability/:id
 * @access  Private (Provider - owner)
 */
const deleteAvailability = async (req, res, next) => {
  try {
    const availability = await Availability.findById(req.params.id);

    if (!availability) {
      return res.status(404).json({
        success: false,
        message: 'Availability slot not found.'
      });
    }

    /* Ensure only the owner can delete the slot. */
    if (availability.provider.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'You are not authorized to delete this availability slot.'
      });
    }

    if (availability.isBlocked) {
      return res.status(400).json({
        success: false,
        message: 'Cannot delete a blocked availability slot linked to a booking.'
      });
    }

    await Availability.findByIdAndDelete(req.params.id);

    res.status(200).json({
      success: true,
      message: 'Availability slot deleted successfully.'
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getProviderAvailability,
  getMyAvailability,
  createAvailability,
  updateAvailability,
  deleteAvailability
};
