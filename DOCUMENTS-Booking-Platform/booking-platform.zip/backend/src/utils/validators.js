/**
 * @module utils/validators
 * @description Express-validator validation chains for request input validation.
 * Provides reusable validation rules for authentication, services, bookings, and availability.
 */

const { body, param, query } = require('express-validator');

/**
 * Validation rules for user registration.
 */
const registerValidation = [
  body('name')
    .trim()
    .notEmpty()
    .withMessage('Name is required')
    .isLength({ min: 2, max: 100 })
    .withMessage('Name must be between 2 and 100 characters'),
  body('email')
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Please provide a valid email address')
    .normalizeEmail(),
  body('password')
    .notEmpty()
    .withMessage('Password is required')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters'),
  body('role')
    .optional()
    .isIn(['customer', 'provider'])
    .withMessage('Role must be either customer or provider')
];

/**
 * Validation rules for user login.
 */
const loginValidation = [
  body('email')
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Please provide a valid email address')
    .normalizeEmail(),
  body('password')
    .notEmpty()
    .withMessage('Password is required')
];

/**
 * Validation rules for creating a service request.
 */
const createServiceValidation = [
  body('title')
    .trim()
    .notEmpty()
    .withMessage('Title is required')
    .isLength({ min: 3, max: 200 })
    .withMessage('Title must be between 3 and 200 characters'),
  body('serviceType')
    .trim()
    .notEmpty()
    .withMessage('Service type is required')
    .isIn([
      'haircut', 'massage', 'cleaning', 'plumbing',
      'electrical', 'tutoring', 'photography', 'catering',
      'landscaping', 'other'
    ])
    .withMessage('Invalid service type'),
  body('description')
    .trim()
    .notEmpty()
    .withMessage('Description is required')
    .isLength({ min: 10, max: 2000 })
    .withMessage('Description must be between 10 and 2000 characters'),
  body('location')
    .trim()
    .notEmpty()
    .withMessage('Location is required'),
  body('preferredTime')
    .notEmpty()
    .withMessage('Preferred time is required')
    .isISO8601()
    .withMessage('Preferred time must be a valid date')
];

/**
 * Validation rules for submitting a bid on a service request.
 */
const submitBidValidation = [
  body('price')
    .notEmpty()
    .withMessage('Price is required')
    .isFloat({ min: 0 })
    .withMessage('Price must be a positive number'),
  body('message')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Message cannot exceed 500 characters')
];

/**
 * Validation rules for creating a booking.
 */
const createBookingValidation = [
  body('serviceId')
    .notEmpty()
    .withMessage('Service ID is required')
    .isMongoId()
    .withMessage('Invalid service ID'),
  body('bidId')
    .notEmpty()
    .withMessage('Bid ID is required')
    .isString()
    .withMessage('Invalid bid ID')
];

/**
 * Validation rules for submitting a rating.
 */
const ratingValidation = [
  body('score')
    .notEmpty()
    .withMessage('Score is required')
    .isInt({ min: 1, max: 5 })
    .withMessage('Score must be between 1 and 5'),
  body('comment')
    .optional()
    .trim()
    .isLength({ max: 1000 })
    .withMessage('Comment cannot exceed 1000 characters')
];

/**
 * Validation rules for creating availability slots.
 */
const availabilityValidation = [
  body('date')
    .notEmpty()
    .withMessage('Date is required')
    .isISO8601()
    .withMessage('Date must be a valid date'),
  body('startTime')
    .notEmpty()
    .withMessage('Start time is required')
    .matches(/^([01]\d|2[0-3]):([0-5]\d)$/)
    .withMessage('Start time must be in HH:mm format'),
  body('endTime')
    .notEmpty()
    .withMessage('End time is required')
    .matches(/^([01]\d|2[0-3]):([0-5]\d)$/)
    .withMessage('End time must be in HH:mm format')
];

/**
 * Validation for MongoDB ObjectId parameters.
 */
const mongoIdValidation = [
  param('id')
    .isMongoId()
    .withMessage('Invalid ID format')
];

module.exports = {
  registerValidation,
  loginValidation,
  createServiceValidation,
  submitBidValidation,
  createBookingValidation,
  ratingValidation,
  availabilityValidation,
  mongoIdValidation
};
