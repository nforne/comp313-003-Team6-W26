/**
 * @module config/db
 * @description Establishes a connection to the MongoDB database using Mongoose.
 * Logs connection status and handles connection errors gracefully.
 */

const mongoose = require('mongoose');
const { MONGODB_URI } = require('./env');

/**
 * Connects to MongoDB using the URI specified in environment variables.
 * @async
 * @function connectDB
 * @returns {Promise<void>} Resolves when the connection is established.
 * @throws {Error} Logs the error and exits the process if connection fails.
 */
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(MONGODB_URI);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`MongoDB Connection Error: ${error.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;
