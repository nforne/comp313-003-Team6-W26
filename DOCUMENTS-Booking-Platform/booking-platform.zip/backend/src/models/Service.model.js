/**
 * @module models/Service
 * @description Mongoose schema and model for the Service Request entity.
 * Represents a service request posted by a customer, which providers can bid on.
 * Maps to the ServiceRequest concept from the project's class and ER diagrams.
 */

const mongoose = require('mongoose');

/**
 * @typedef {Object} Bid
 * @property {ObjectId} provider - Reference to the provider who submitted the bid.
 * @property {number} price - The bid price offered by the provider.
 * @property {string} [message] - Optional message from the provider.
 * @property {Date} createdAt - Timestamp when the bid was submitted.
 */
const bidSchema = new mongoose.Schema(
  {
    provider: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    price: {
      type: Number,
      required: [true, 'Bid price is required'],
      min: [0, 'Price must be a positive number']
    },
    message: {
      type: String,
      trim: true,
      maxlength: [500, 'Message cannot exceed 500 characters'],
      default: ''
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  },
  { _id: true }
);

/**
 * @typedef {Object} Service
 * @property {ObjectId} customer - Reference to the customer who created the request.
 * @property {string} title - Short title describing the service needed.
 * @property {string} serviceType - Category of the service (e.g., haircut, massage).
 * @property {string} description - Detailed description of the service request.
 * @property {string} location - Location where the service is needed.
 * @property {Date} preferredTime - Preferred date and time for the service.
 * @property {string} status - Current status: open, in_progress, completed, cancelled.
 * @property {Bid[]} bids - Array of bids submitted by providers.
 * @property {ObjectId} [selectedProvider] - The provider chosen for the service.
 * @property {number} [selectedBidPrice] - The price of the accepted bid.
 */
const serviceSchema = new mongoose.Schema(
  {
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Customer reference is required']
    },
    title: {
      type: String,
      required: [true, 'Service title is required'],
      trim: true,
      minlength: [3, 'Title must be at least 3 characters'],
      maxlength: [200, 'Title cannot exceed 200 characters']
    },
    serviceType: {
      type: String,
      required: [true, 'Service type is required'],
      trim: true,
      enum: [
        'haircut',
        'massage',
        'cleaning',
        'plumbing',
        'electrical',
        'tutoring',
        'photography',
        'catering',
        'landscaping',
        'other'
      ]
    },
    description: {
      type: String,
      required: [true, 'Description is required'],
      trim: true,
      minlength: [10, 'Description must be at least 10 characters'],
      maxlength: [2000, 'Description cannot exceed 2000 characters']
    },
    location: {
      type: String,
      required: [true, 'Location is required'],
      trim: true
    },
    preferredTime: {
      type: Date,
      required: [true, 'Preferred time is required']
    },
    status: {
      type: String,
      enum: ['open', 'in_progress', 'completed', 'cancelled'],
      default: 'open'
    },
    bids: [bidSchema],
    selectedProvider: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null
    },
    selectedBidPrice: {
      type: Number,
      default: null
    }
  },
  {
    timestamps: true
  }
);

/** Index for efficient querying by status and customer. */
serviceSchema.index({ status: 1 });
serviceSchema.index({ customer: 1 });
serviceSchema.index({ serviceType: 1 });

const Service = mongoose.model('Service', serviceSchema);

module.exports = Service;
