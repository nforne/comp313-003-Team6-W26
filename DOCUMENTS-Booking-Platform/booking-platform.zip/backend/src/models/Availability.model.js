/**
 * @module models/Availability
 * @description Mongoose schema and model for the Availability entity.
 * Represents time slots that a service provider has marked as available or blocked.
 * Used for calendar management and preventing double bookings.
 */

const mongoose = require('mongoose');

/**
 * @typedef {Object} Availability
 * @property {ObjectId} provider - Reference to the provider who owns this time slot.
 * @property {Date} date - The date of the availability slot.
 * @property {string} startTime - Start time in HH:mm format.
 * @property {string} endTime - End time in HH:mm format.
 * @property {boolean} isBlocked - Whether this time slot is blocked (e.g., due to a booking).
 * @property {ObjectId} [bookingRef] - Reference to the booking that blocked this slot.
 */
const availabilitySchema = new mongoose.Schema(
  {
    provider: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Provider reference is required']
    },
    date: {
      type: Date,
      required: [true, 'Date is required']
    },
    startTime: {
      type: String,
      required: [true, 'Start time is required'],
      match: [/^([01]\d|2[0-3]):([0-5]\d)$/, 'Start time must be in HH:mm format']
    },
    endTime: {
      type: String,
      required: [true, 'End time is required'],
      match: [/^([01]\d|2[0-3]):([0-5]\d)$/, 'End time must be in HH:mm format']
    },
    isBlocked: {
      type: Boolean,
      default: false
    },
    bookingRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Booking',
      default: null
    }
  },
  {
    timestamps: true
  }
);

/** Compound index for efficient querying of provider availability by date. */
availabilitySchema.index({ provider: 1, date: 1 });

const Availability = mongoose.model('Availability', availabilitySchema);

module.exports = Availability;
