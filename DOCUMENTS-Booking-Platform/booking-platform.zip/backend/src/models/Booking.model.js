/**
 * @module models/Booking
 * @description Mongoose schema and model for the Booking entity.
 * Represents a confirmed appointment between a customer and a service provider.
 * Includes rating and review functionality for completed bookings.
 */

const mongoose = require('mongoose');

/**
 * @typedef {Object} Rating
 * @property {number} score - Rating score from 1 to 5.
 * @property {string} comment - Review comment from the customer.
 * @property {Date} createdAt - Timestamp when the rating was submitted.
 */
const ratingSchema = new mongoose.Schema(
  {
    score: {
      type: Number,
      required: [true, 'Rating score is required'],
      min: [1, 'Score must be at least 1'],
      max: [5, 'Score cannot exceed 5']
    },
    comment: {
      type: String,
      trim: true,
      maxlength: [1000, 'Comment cannot exceed 1000 characters'],
      default: ''
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  },
  { _id: false }
);

/**
 * @typedef {Object} Booking
 * @property {ObjectId} service - Reference to the service request.
 * @property {ObjectId} customer - Reference to the customer who made the booking.
 * @property {ObjectId} provider - Reference to the service provider.
 * @property {Date} scheduledTime - The confirmed date and time for the service.
 * @property {string} status - Booking status: pending, confirmed, completed, cancelled.
 * @property {number} price - The agreed price for the service.
 * @property {string} [notes] - Additional notes for the booking.
 * @property {Rating} [rating] - Customer rating and review after service completion.
 */
const bookingSchema = new mongoose.Schema(
  {
    service: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Service',
      required: [true, 'Service reference is required']
    },
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Customer reference is required']
    },
    provider: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Provider reference is required']
    },
    scheduledTime: {
      type: Date,
      required: [true, 'Scheduled time is required']
    },
    status: {
      type: String,
      enum: ['pending', 'confirmed', 'completed', 'cancelled'],
      default: 'pending'
    },
    price: {
      type: Number,
      required: [true, 'Price is required'],
      min: [0, 'Price must be a positive number']
    },
    notes: {
      type: String,
      trim: true,
      maxlength: [1000, 'Notes cannot exceed 1000 characters'],
      default: ''
    },
    rating: {
      type: ratingSchema,
      default: null
    }
  },
  {
    timestamps: true
  }
);

/** Indexes for efficient querying. */
bookingSchema.index({ customer: 1, status: 1 });
bookingSchema.index({ provider: 1, status: 1 });
bookingSchema.index({ service: 1 });

const Booking = mongoose.model('Booking', bookingSchema);

module.exports = Booking;
