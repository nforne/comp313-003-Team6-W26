# Booking Platform - Backend API

## Overview
RESTful API backend for the Local Service Booking Platform built with Node.js, Express, and MongoDB.

## Tech Stack
- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: MongoDB with Mongoose ODM
- **Authentication**: JWT (JSON Web Tokens)
- **Validation**: express-validator

## Setup Instructions

### Prerequisites
- Node.js (v18+)
- MongoDB (local or cloud instance like MongoDB Atlas)

### Installation
```bash
cd backend
npm install
```

### Environment Variables
Create a `.env` file in the backend root:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/booking_platform
JWT_SECRET=your_jwt_secret_key
JWT_EXPIRES_IN=7d
NODE_ENV=development
CLIENT_URL=http://localhost:5173
```

### Running the Server
```bash
# Development mode (with hot reload)
npm run dev

# Production mode
npm start
```

### Seed Database
```bash
node seed.js
```

### Run Tests
```bash
npm test
```

## API Endpoints

### Authentication
| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| POST | /api/auth/register | Register new user | Public |
| POST | /api/auth/login | Login user | Public |
| POST | /api/auth/logout | Logout user | Private |
| GET | /api/auth/me | Get current user profile | Private |
| PUT | /api/auth/me | Update user profile | Private |

### Services
| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | /api/services | Get all open services | Public |
| GET | /api/services/:id | Get service by ID | Public |
| POST | /api/services | Create service request | Customer |
| PUT | /api/services/:id | Update service request | Customer (owner) |
| DELETE | /api/services/:id | Cancel service request | Customer/Admin |
| POST | /api/services/:id/bids | Submit bid | Provider |
| GET | /api/services/my-requests | Get my service requests | Customer |
| GET | /api/services/my-bids | Get services I bid on | Provider |

### Bookings
| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | /api/bookings | Get my bookings | Private |
| GET | /api/bookings/:id | Get booking by ID | Private |
| POST | /api/bookings | Create booking (accept bid) | Customer |
| PUT | /api/bookings/:id/status | Update booking status | Private |
| POST | /api/bookings/:id/rating | Submit rating | Customer |

### Availability
| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | /api/availability | Get my availability | Provider |
| GET | /api/availability/provider/:id | Get provider availability | Public |
| POST | /api/availability | Create availability slot | Provider |
| PUT | /api/availability/:id | Update availability slot | Provider |
| DELETE | /api/availability/:id | Delete availability slot | Provider |

### Admin
| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | /api/admin/stats | Get platform statistics | Admin |
| GET | /api/admin/users | Get all users | Admin |
| GET | /api/admin/users/:id | Get user by ID | Admin |
| PUT | /api/admin/users/:id | Update user | Admin |
| DELETE | /api/admin/users/:id | Delete user | Admin |
| GET | /api/admin/bookings | Get all bookings | Admin |
| GET | /api/admin/reviews | Get all reviews | Admin |
| DELETE | /api/admin/reviews/:id | Delete review | Admin |

## Test Accounts (after seeding)
| Role | Email | Password |
|------|-------|----------|
| Admin | admin@booking.com | admin123 |
| Provider | john@booking.com | provider123 |
| Provider | sarah@booking.com | provider123 |
| Provider | mike@booking.com | provider123 |
| Customer | alice@booking.com | customer123 |
| Customer | bob@booking.com | customer123 |
