# Booking Platform - Frontend

## Overview
React frontend for the Local Service Booking Platform built with Vite, React, and TailwindCSS.

## Tech Stack
- **Build Tool**: Vite
- **Framework**: React 19
- **Styling**: TailwindCSS v4
- **Routing**: React Router v7
- **HTTP Client**: Axios
- **Notifications**: React Hot Toast
- **Icons**: React Icons

## Setup Instructions

### Prerequisites
- Node.js (v18+)
- Backend API running on port 5000

### Installation
```bash
cd frontend
npm install
```

### Running the Dev Server
```bash
npm run dev
```
The app will be available at http://localhost:5173

### Build for Production
```bash
npm run build
```

## Project Structure
```
src/
├── api/          # Axios instance and API functions
├── app/          # Main App component with routes
├── auth/         # Auth context, guards
├── components/   # Reusable UI components
├── hooks/        # Custom hooks
├── layouts/      # Layout wrappers
└── pages/        # Page components by role
    ├── public/   # Home, Services, Login, Register
    ├── customer/ # Customer dashboard, bookings
    ├── provider/ # Provider dashboard, availability
    ├── admin/    # Admin dashboard, user management
    └── viewer/   # Favorites (future)
```
