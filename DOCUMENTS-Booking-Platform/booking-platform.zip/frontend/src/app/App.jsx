/**
 * @file App.jsx
 * @description Main application component with route configuration.
 * Defines all routes for public, customer, provider, and admin sections.
 */

import { Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import useAuth from '../hooks/useAuth';
import Loading from '../components/Loading';

/* Layouts */
import PublicLayout from '../layouts/PublicLayout';
import CustomerLayout from '../layouts/CustomerLayout';
import ProviderLayout from '../layouts/ProviderLayout';
import AdminLayout from '../layouts/AdminLayout';

/* Auth Guards */
import RequireAuth from '../auth/RequireAuth';
import RequireRole from '../auth/RequireRole';

/* Public Pages */
import Home from '../pages/public/Home';
import Services from '../pages/public/Services';
import ServiceDetail from '../pages/public/ServiceDetail';
import Login from '../pages/public/Login';
import Register from '../pages/public/Register';

/* Customer Pages */
import CustomerDashboard from '../pages/customer/Dashboard';
import MyBookings from '../pages/customer/MyBookings';
import BookingDetail from '../pages/customer/BookingDetail';
import NewRequest from '../pages/customer/NewRequest';

/* Provider Pages */
import ProviderDashboard from '../pages/provider/Dashboard';
import MyServices from '../pages/provider/MyServices';
import ProviderAvailability from '../pages/provider/Availability';
import ProviderBookings from '../pages/provider/ProviderBookings';

/* Admin Pages */
import AdminDashboard from '../pages/admin/Dashboard';
import AdminUsers from '../pages/admin/Users';
import AdminProviders from '../pages/admin/Providers';
import AdminBookings from '../pages/admin/Bookings';

/* Viewer Pages */
import Favorites from '../pages/viewer/Favorites';

const App = () => {
  const { loading } = useAuth();

  if (loading) return <Loading />;

  return (
    <>
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 3000,
          style: { background: '#363636', color: '#fff' }
        }}
      />

      <Routes>
        {/* ===== Public Routes ===== */}
        <Route element={<PublicLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/services/:id" element={<ServiceDetail />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/favorites" element={<Favorites />} />
        </Route>

        {/* ===== Customer Routes ===== */}
        <Route
          element={
            <RequireAuth>
              <RequireRole roles={['customer']}>
                <CustomerLayout />
              </RequireRole>
            </RequireAuth>
          }
        >
          <Route path="/customer/dashboard" element={<CustomerDashboard />} />
          <Route path="/customer/my-bookings" element={<MyBookings />} />
          <Route path="/customer/bookings/:id" element={<BookingDetail />} />
          <Route path="/customer/new-request" element={<NewRequest />} />
        </Route>

        {/* ===== Provider Routes ===== */}
        <Route
          element={
            <RequireAuth>
              <RequireRole roles={['provider']}>
                <ProviderLayout />
              </RequireRole>
            </RequireAuth>
          }
        >
          <Route path="/provider/dashboard" element={<ProviderDashboard />} />
          <Route path="/provider/my-services" element={<MyServices />} />
          <Route path="/provider/availability" element={<ProviderAvailability />} />
          <Route path="/provider/bookings" element={<ProviderBookings />} />
        </Route>

        {/* ===== Admin Routes ===== */}
        <Route
          element={
            <RequireAuth>
              <RequireRole roles={['admin']}>
                <AdminLayout />
              </RequireRole>
            </RequireAuth>
          }
        >
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/users" element={<AdminUsers />} />
          <Route path="/admin/providers" element={<AdminProviders />} />
          <Route path="/admin/bookings" element={<AdminBookings />} />
        </Route>

        {/* ===== Catch-all ===== */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
};

export default App;
