/**
 * @file BookingForm.jsx
 * @description Form component for creating a new service request.
 */

import { useState } from 'react';
import toast from 'react-hot-toast';
import { createService } from '../api/services.api';

const SERVICE_TYPES = [
  'haircut', 'massage', 'cleaning', 'plumbing',
  'electrical', 'tutoring', 'photography', 'catering',
  'landscaping', 'other'
];

/**
 * BookingForm component for creating service requests.
 * @param {Object} props - Component props.
 * @param {Function} props.onSuccess - Callback after successful creation.
 */
const BookingForm = ({ onSuccess }) => {
  const [formData, setFormData] = useState({
    title: '',
    serviceType: '',
    description: '',
    location: '',
    preferredTime: ''
  });
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await createService(formData);
      toast.success('Service request created successfully!');
      setFormData({
        title: '',
        serviceType: '',
        description: '',
        location: '',
        preferredTime: ''
      });
      if (onSuccess) onSuccess();
    } catch (error) {
      const msg = error.response?.data?.message || 'Failed to create service request.';
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
        <input
          type="text"
          name="title"
          value={formData.title}
          onChange={handleChange}
          required
          minLength={3}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="e.g., Need a Haircut at Home"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Service Type</label>
        <select
          name="serviceType"
          value={formData.serviceType}
          onChange={handleChange}
          required
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="">Select a service type</option>
          {SERVICE_TYPES.map((type) => (
            <option key={type} value={type}>
              {type.charAt(0).toUpperCase() + type.slice(1)}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
        <textarea
          name="description"
          value={formData.description}
          onChange={handleChange}
          required
          minLength={10}
          rows={4}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="Describe the service you need in detail..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
        <input
          type="text"
          name="location"
          value={formData.location}
          onChange={handleChange}
          required
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="e.g., 123 Main Street, Toronto, ON"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Preferred Date & Time</label>
        <input
          type="datetime-local"
          name="preferredTime"
          value={formData.preferredTime}
          onChange={handleChange}
          required
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      <button
        type="submit"
        disabled={submitting}
        className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition font-medium disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {submitting ? 'Creating...' : 'Create Service Request'}
      </button>
    </form>
  );
};

export default BookingForm;
