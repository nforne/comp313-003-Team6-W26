/**
 * @file ServiceCard.jsx
 * @description Reusable card component for displaying service request summaries.
 */

import { Link } from 'react-router-dom';
import { FiMapPin, FiClock, FiTag, FiMessageSquare } from 'react-icons/fi';

/**
 * Formats a date string into a readable format.
 * @param {string} dateStr - ISO date string.
 * @returns {string} Formatted date string.
 */
const formatDate = (dateStr) => {
  return new Date(dateStr).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

/** Color mapping for service status badges. */
const STATUS_COLORS = {
  open: 'bg-green-100 text-green-800',
  in_progress: 'bg-yellow-100 text-yellow-800',
  completed: 'bg-blue-100 text-blue-800',
  cancelled: 'bg-red-100 text-red-800'
};

/**
 * ServiceCard component.
 * @param {Object} props - Component props.
 * @param {Object} props.service - Service request data.
 */
const ServiceCard = ({ service }) => {
  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow p-6 border border-gray-100">
      <div className="flex justify-between items-start mb-3">
        <h3 className="text-lg font-semibold text-gray-800 line-clamp-1">
          {service.title}
        </h3>
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${STATUS_COLORS[service.status] || 'bg-gray-100 text-gray-800'}`}>
          {service.status.replace('_', ' ')}
        </span>
      </div>

      <p className="text-gray-600 text-sm mb-4 line-clamp-2">
        {service.description}
      </p>

      <div className="space-y-2 text-sm text-gray-500 mb-4">
        <div className="flex items-center gap-2">
          <FiTag className="text-blue-500" />
          <span className="capitalize">{service.serviceType}</span>
        </div>
        <div className="flex items-center gap-2">
          <FiMapPin className="text-red-500" />
          <span>{service.location}</span>
        </div>
        <div className="flex items-center gap-2">
          <FiClock className="text-green-500" />
          <span>{formatDate(service.preferredTime)}</span>
        </div>
        <div className="flex items-center gap-2">
          <FiMessageSquare className="text-purple-500" />
          <span>{service.bids?.length || 0} bid(s)</span>
        </div>
      </div>

      {service.customer && (
        <p className="text-xs text-gray-400 mb-3">
          Posted by: {service.customer.name}
        </p>
      )}

      <Link
        to={`/services/${service._id}`}
        className="inline-block w-full text-center bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition text-sm font-medium"
      >
        View Details
      </Link>
    </div>
  );
};

export default ServiceCard;
