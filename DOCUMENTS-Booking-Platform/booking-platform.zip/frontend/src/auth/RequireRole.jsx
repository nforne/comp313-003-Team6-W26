/**
 * @file RequireRole.jsx
 * @description Route guard component that requires a specific user role.
 * Redirects users without the required role to the home page.
 */

import { Navigate } from 'react-router-dom';
import useAuth from '../hooks/useAuth';
import Loading from '../components/Loading';

/**
 * RequireRole wrapper component.
 * @param {Object} props - Component props.
 * @param {string[]} props.roles - Array of allowed roles.
 * @param {React.ReactNode} props.children - Protected child components.
 */
const RequireRole = ({ roles, children }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return <Loading />;
  }

  if (!user || !roles.includes(user.role)) {
    return <Navigate to="/" replace />;
  }

  return children;
};

export default RequireRole;
