/**
 * @file AuthProvider.jsx
 * @description Authentication context provider.
 * Manages user state, login, registration, logout, and token persistence.
 */

import { createContext, useState, useEffect } from 'react';
import { loginUser, registerUser, getProfile } from '../api/auth.api';

export const AuthContext = createContext(null);

/**
 * AuthProvider component that wraps the application and provides auth state.
 * @param {Object} props - Component props.
 * @param {React.ReactNode} props.children - Child components.
 */
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  /** Check for existing token on mount and restore user session. */
  useEffect(() => {
    const initAuth = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const res = await getProfile();
          setUser(res.data.data.user);
        } catch {
          localStorage.removeItem('token');
          localStorage.removeItem('user');
        }
      }
      setLoading(false);
    };
    initAuth();
  }, []);

  /**
   * Login function.
   * @param {string} email - User email.
   * @param {string} password - User password.
   * @returns {Object} Response data.
   */
  const login = async (email, password) => {
    const res = await loginUser({ email, password });
    const { user: userData, token } = res.data.data;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
    return res.data;
  };

  /**
   * Register function.
   * @param {Object} data - Registration data (name, email, password, role).
   * @returns {Object} Response data.
   */
  const register = async (data) => {
    const res = await registerUser(data);
    const { user: userData, token } = res.data.data;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
    return res.data;
  };

  /** Logout function. Clears token and user state. */
  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  };

  const value = {
    user,
    loading,
    login,
    register,
    logout,
    isAuthenticated: !!user
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
