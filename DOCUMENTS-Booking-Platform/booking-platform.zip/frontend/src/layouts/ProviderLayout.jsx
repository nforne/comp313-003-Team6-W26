/**
 * @file ProviderLayout.jsx
 * @description Layout wrapper for provider dashboard pages with sidebar navigation.
 */

import { Outlet, Link, useLocation } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { FiHome, FiList, FiCalendar, FiBookOpen } from 'react-icons/fi';

const MENU_ITEMS = [
  { path: '/provider/dashboard', label: 'Dashboard', icon: FiHome },
  { path: '/provider/my-services', label: 'Browse Requests', icon: FiList },
  { path: '/provider/availability', label: 'Availability', icon: FiCalendar },
  { path: '/provider/bookings', label: 'My Bookings', icon: FiBookOpen }
];

const ProviderLayout = () => {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />
      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className="w-64 bg-white shadow-md hidden md:block">
          <div className="p-4">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">Provider Panel</h2>
            <nav className="space-y-1">
              {MENU_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition ${
                      isActive
                        ? 'bg-green-50 text-green-600 font-medium'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <Icon size={18} />
                    {item.label}
                  </Link>
                );
              })}
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default ProviderLayout;
