/**
 * @file PublicLayout.jsx
 * @description Layout wrapper for public pages with navbar and footer.
 */

import { Outlet } from 'react-router-dom';
import Navbar from '../components/Navbar';

const PublicLayout = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />
      <main className="flex-1">
        <Outlet />
      </main>
      <footer className="bg-white border-t py-6 text-center text-gray-500 text-sm">
        <p>&copy; 2026 BookingPlatform. COMP313 - Team 6. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default PublicLayout;
