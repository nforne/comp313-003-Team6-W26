/**
 * @file useAuth.js
 * @description Custom hook for accessing authentication context.
 */

import { useContext } from 'react';
import { AuthContext } from '../auth/AuthProvider';

/**
 * Hook to access the authentication context.
 * @returns {Object} Auth context with user, login, register, logout, loading state.
 */
const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default useAuth;
