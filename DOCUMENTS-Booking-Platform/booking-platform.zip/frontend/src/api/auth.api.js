/**
 * @file auth.api.js
 * @description API functions for authentication endpoints.
 */

import API from './axios';

/** Register a new user. */
export const registerUser = (data) => API.post('/auth/register', data);

/** Login user with email and password. */
export const loginUser = (data) => API.post('/auth/login', data);

/** Logout the current user. */
export const logoutUser = () => API.post('/auth/logout');

/** Get the current user's profile. */
export const getProfile = () => API.get('/auth/me');

/** Update the current user's profile. */
export const updateProfile = (data) => API.put('/auth/me', data);
