/**
 * @file bookings.api.js
 * @description API functions for booking and availability endpoints.
 */

import API from './axios';

/** Get bookings for the current user. */
export const getMyBookings = (params) => API.get('/bookings', { params });

/** Get a single booking by ID. */
export const getBookingById = (id) => API.get(`/bookings/${id}`);

/** Create a booking by accepting a bid. */
export const createBooking = (data) => API.post('/bookings', data);

/** Update booking status. */
export const updateBookingStatus = (id, status) => API.put(`/bookings/${id}/status`, { status });

/** Submit a rating for a completed booking. */
export const submitRating = (bookingId, data) => API.post(`/bookings/${bookingId}/rating`, data);

/** Get provider availability. */
export const getProviderAvailability = (providerId, params) =>
  API.get(`/availability/provider/${providerId}`, { params });

/** Get current provider's availability. */
export const getMyAvailability = () => API.get('/availability');

/** Create an availability slot. */
export const createAvailability = (data) => API.post('/availability', data);

/** Update an availability slot. */
export const updateAvailability = (id, data) => API.put(`/availability/${id}`, data);

/** Delete an availability slot. */
export const deleteAvailability = (id) => API.delete(`/availability/${id}`);

/* ===== Admin API ===== */

/** Get platform statistics. */
export const getAdminStats = () => API.get('/admin/stats');

/** Get all users (admin). */
export const getAdminUsers = (params) => API.get('/admin/users', { params });

/** Update a user (admin). */
export const updateAdminUser = (id, data) => API.put(`/admin/users/${id}`, data);

/** Delete a user (admin). */
export const deleteAdminUser = (id) => API.delete(`/admin/users/${id}`);

/** Get all bookings (admin). */
export const getAdminBookings = (params) => API.get('/admin/bookings', { params });

/** Get all reviews (admin). */
export const getAdminReviews = () => API.get('/admin/reviews');

/** Delete a review (admin). */
export const deleteAdminReview = (bookingId) => API.delete(`/admin/reviews/${bookingId}`);
