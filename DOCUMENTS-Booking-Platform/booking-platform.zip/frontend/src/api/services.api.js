/**
 * @file services.api.js
 * @description API functions for service request endpoints.
 */

import API from './axios';

/** Get all open service requests with optional filters. */
export const getServices = (params) => API.get('/services', { params });

/** Get a single service request by ID. */
export const getServiceById = (id) => API.get(`/services/${id}`);

/** Create a new service request. */
export const createService = (data) => API.post('/services', data);

/** Update a service request. */
export const updateService = (id, data) => API.put(`/services/${id}`, data);

/** Cancel a service request. */
export const deleteService = (id) => API.delete(`/services/${id}`);

/** Submit a bid on a service request. */
export const submitBid = (serviceId, data) => API.post(`/services/${serviceId}/bids`, data);

/** Get service requests created by the current customer. */
export const getMyServices = () => API.get('/services/my-requests');

/** Get service requests where the current provider has bids. */
export const getMyBids = () => API.get('/services/my-bids');
