/**
 * @file admin/Providers.jsx
 * @description Admin page for review moderation.
 */

import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { getAdminReviews, deleteAdminReview } from '../../api/bookings.api';
import Loading from '../../components/Loading';
import { FiTrash2, FiStar } from 'react-icons/fi';

const Providers = () => {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchReviews();
  }, []);

  const fetchReviews = async () => {
    try {
      const res = await getAdminReviews();
      setReviews(res.data.data.reviews);
    } catch (error) {
      console.error('Failed to fetch reviews:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (bookingId) => {
    if (!window.confirm('Delete this review?')) return;
    try {
      await deleteAdminReview(bookingId);
      toast.success('Review deleted.');
      fetchReviews();
    } catch (error) {
      toast.error('Failed to delete review.');
    }
  };

  if (loading) return <Loading />;

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Review Moderation</h1>

      {reviews.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-xl shadow">
          <p className="text-gray-500 text-lg">No reviews to moderate.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {reviews.map((review) => (
            <div key={review._id} className="bg-white rounded-xl shadow p-6">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-semibold text-gray-800">
                    {review.service?.title || 'Service'}
                  </h3>
                  <p className="text-sm text-gray-500">
                    Customer: {review.customer?.name} | Provider: {review.provider?.name}
                  </p>
                  <div className="flex items-center gap-1 mt-2">
                    {[1, 2, 3, 4, 5].map((score) => (
                      <FiStar
                        key={score}
                        size={16}
                        className={score <= review.rating?.score ? 'text-yellow-400' : 'text-gray-300'}
                        fill={score <= review.rating?.score ? 'currentColor' : 'none'}
                      />
                    ))}
                    <span className="text-sm text-gray-600 ml-1">({review.rating?.score}/5)</span>
                  </div>
                  {review.rating?.comment && (
                    <p className="text-gray-600 mt-2 italic">"{review.rating.comment}"</p>
                  )}
                </div>
                <button
                  onClick={() => handleDelete(review._id)}
                  className="text-red-500 hover:text-red-700 p-2"
                  title="Delete review"
                >
                  <FiTrash2 size={18} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Providers;
