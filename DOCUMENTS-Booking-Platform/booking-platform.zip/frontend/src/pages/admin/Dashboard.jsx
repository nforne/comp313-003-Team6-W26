/**
 * @file admin/Dashboard.jsx
 * @description Admin dashboard showing platform statistics and overview.
 */

import { useState, useEffect } from 'react';
import { getAdminStats } from '../../api/bookings.api';
import Loading from '../../components/Loading';
import { FiUsers, FiList, FiBookOpen, FiDollarSign } from 'react-icons/fi';

const Dashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await getAdminStats();
        setStats(res.data.data.stats);
      } catch (error) {
        console.error('Failed to fetch stats:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  if (loading) return <Loading />;

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-2">Admin Dashboard</h1>
      <p className="text-gray-600 mb-8">Platform overview and statistics.</p>

      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl shadow p-6 border-l-4 border-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Users</p>
                <p className="text-3xl font-bold text-gray-800">{stats.totalUsers}</p>
              </div>
              <FiUsers className="text-blue-500" size={32} />
            </div>
          </div>
          <div className="bg-white rounded-xl shadow p-6 border-l-4 border-green-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Services</p>
                <p className="text-3xl font-bold text-gray-800">{stats.totalServices}</p>
              </div>
              <FiList className="text-green-500" size={32} />
            </div>
          </div>
          <div className="bg-white rounded-xl shadow p-6 border-l-4 border-purple-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Bookings</p>
                <p className="text-3xl font-bold text-gray-800">{stats.totalBookings}</p>
              </div>
              <FiBookOpen className="text-purple-500" size={32} />
            </div>
          </div>
          <div className="bg-white rounded-xl shadow p-6 border-l-4 border-yellow-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Revenue</p>
                <p className="text-3xl font-bold text-gray-800">${stats.totalRevenue || 0}</p>
              </div>
              <FiDollarSign className="text-yellow-500" size={32} />
            </div>
          </div>
        </div>
      )}

      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-xl shadow p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">Users by Role</h2>
            <div className="space-y-3">
              {stats.usersByRole?.map((item) => (
                <div key={item._id} className="flex justify-between items-center">
                  <span className="capitalize text-gray-600">{item._id}</span>
                  <span className="font-bold text-gray-800">{item.count}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white rounded-xl shadow p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">Bookings by Status</h2>
            <div className="space-y-3">
              {stats.bookingsByStatus?.map((item) => (
                <div key={item._id} className="flex justify-between items-center">
                  <span className="capitalize text-gray-600">{item._id}</span>
                  <span className="font-bold text-gray-800">{item.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
