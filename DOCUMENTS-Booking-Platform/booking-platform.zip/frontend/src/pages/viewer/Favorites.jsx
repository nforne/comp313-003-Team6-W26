/**
 * @file viewer/Favorites.jsx
 * @description Favorites page for viewers (placeholder for future implementation).
 */

import { FiHeart } from 'react-icons/fi';

const Favorites = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-16 text-center">
      <FiHeart className="mx-auto text-gray-400 mb-4" size={48} />
      <h1 className="text-2xl font-bold text-gray-800 mb-2">Your Favorites</h1>
      <p className="text-gray-600">
        Save your favorite services and providers here for quick access.
        This feature is coming soon!
      </p>
    </div>
  );
};

export default Favorites;
