/**
 * @file customer/Dashboard.jsx
 * @description Customer dashboard showing overview of service requests and bookings.
 */

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';
import { getMyServices } from '../../api/services.api';
import { getMyBookings } from '../../api/bookings.api';
import { FiPlusCircle, FiList, FiCheckCircle, FiClock } from 'react-icons/fi';

const Dashboard = () => {
  const { user } = useAuth();
  const [services, setServices] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [servRes, bookRes] = await Promise.all([
          getMyServices(),
          getMyBookings()
        ]);
        setServices(servRes.data.data.services);
        setBookings(bookRes.data.data.bookings);
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const openRequests = services.filter((s) => s.status === 'open').length;
  const activeBookings = bookings.filter((b) => b.status === 'confirmed').length;
  const completedBookings = bookings.filter((b) => b.status === 'completed').length;

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-2">
        Welcome back, {user?.name}!
      </h1>
      <p className="text-gray-600 mb-8">Here's an overview of your activity.</p>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-xl shadow p-6 border-l-4 border-blue-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Requests</p>
              <p className="text-3xl font-bold text-gray-800">{services.length}</p>
            </div>
            <FiList className="text-blue-500" size={32} />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow p-6 border-l-4 border-green-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Open Requests</p>
              <p className="text-3xl font-bold text-gray-800">{openRequests}</p>
            </div>
            <FiClock className="text-green-500" size={32} />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow p-6 border-l-4 border-yellow-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Active Bookings</p>
              <p className="text-3xl font-bold text-gray-800">{activeBookings}</p>
            </div>
            <FiCheckCircle className="text-yellow-500" size={32} />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow p-6 border-l-4 border-purple-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Completed</p>
              <p className="text-3xl font-bold text-gray-800">{completedBookings}</p>
            </div>
            <FiCheckCircle className="text-purple-500" size={32} />
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="flex gap-4 mb-8">
        <Link
          to="/customer/new-request"
          className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition font-medium"
        >
          <FiPlusCircle /> New Service Request
        </Link>
        <Link
          to="/customer/my-bookings"
          className="flex items-center gap-2 bg-white text-gray-700 px-6 py-3 rounded-lg border border-gray-300 hover:bg-gray-50 transition font-medium"
        >
          <FiList /> View My Bookings
        </Link>
      </div>

      {/* Recent Service Requests */}
      <div className="bg-white rounded-xl shadow p-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Recent Service Requests</h2>
        {services.length === 0 ? (
          <p className="text-gray-500">You haven't created any service requests yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-gray-500 border-b">
                  <th className="pb-3 font-medium">Title</th>
                  <th className="pb-3 font-medium">Type</th>
                  <th className="pb-3 font-medium">Bids</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {services.slice(0, 5).map((service) => (
                  <tr key={service._id} className="border-b hover:bg-gray-50">
                    <td className="py-3">
                      <Link to={`/services/${service._id}`} className="text-blue-600 hover:underline">
                        {service.title}
                      </Link>
                    </td>
                    <td className="py-3 capitalize">{service.serviceType}</td>
                    <td className="py-3">{service.bids?.length || 0}</td>
                    <td className="py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        service.status === 'open' ? 'bg-green-100 text-green-800' :
                        service.status === 'in_progress' ? 'bg-yellow-100 text-yellow-800' :
                        service.status === 'completed' ? 'bg-blue-100 text-blue-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {service.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 text-gray-500">
                      {new Date(service.createdAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
