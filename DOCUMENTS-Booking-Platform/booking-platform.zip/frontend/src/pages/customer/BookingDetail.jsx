/**
 * @file customer/BookingDetail.jsx
 * @description Detailed view of a booking with rating functionality.
 */

import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { getBookingById, submitRating, updateBookingStatus } from '../../api/bookings.api';
import Loading from '../../components/Loading';
import { FiStar } from 'react-icons/fi';

const formatDate = (dateStr) => {
  return new Date(dateStr).toLocaleDateString('en-US', {
    year: 'numeric', month: 'long', day: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
};

const BookingDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);
  const [ratingScore, setRatingScore] = useState(5);
  const [ratingComment, setRatingComment] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchBooking();
  }, [id]);

  const fetchBooking = async () => {
    try {
      const res = await getBookingById(id);
      setBooking(res.data.data.booking);
    } catch (error) {
      toast.error('Failed to load booking details.');
      navigate('/customer/my-bookings');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitRating = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await submitRating(id, { score: ratingScore, comment: ratingComment });
      toast.success('Rating submitted successfully!');
      fetchBooking();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to submit rating.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancel = async () => {
    if (!window.confirm('Are you sure you want to cancel this booking?')) return;
    try {
      await updateBookingStatus(id, 'cancelled');
      toast.success('Booking cancelled.');
      fetchBooking();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to cancel booking.');
    }
  };

  if (loading) return <Loading />;
  if (!booking) return null;

  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Booking Details</h1>

      <div className="bg-white rounded-xl shadow p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-500">Service</p>
            <p className="font-medium text-gray-800">{booking.service?.title}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Type</p>
            <p className="font-medium text-gray-800 capitalize">{booking.service?.serviceType}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Provider</p>
            <p className="font-medium text-gray-800">{booking.provider?.name}</p>
            <p className="text-xs text-gray-500">{booking.provider?.email}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Scheduled Time</p>
            <p className="font-medium text-gray-800">{formatDate(booking.scheduledTime)}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Price</p>
            <p className="text-xl font-bold text-green-600">${booking.price}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Status</p>
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
              booking.status === 'confirmed' ? 'bg-green-100 text-green-800' :
              booking.status === 'completed' ? 'bg-blue-100 text-blue-800' :
              booking.status === 'cancelled' ? 'bg-red-100 text-red-800' :
              'bg-yellow-100 text-yellow-800'
            }`}>
              {booking.status}
            </span>
          </div>
          {booking.service?.location && (
            <div className="md:col-span-2">
              <p className="text-sm text-gray-500">Location</p>
              <p className="font-medium text-gray-800">{booking.service.location}</p>
            </div>
          )}
        </div>

        {(booking.status === 'pending' || booking.status === 'confirmed') && (
          <button
            onClick={handleCancel}
            className="mt-6 bg-red-500 text-white px-6 py-2 rounded-lg hover:bg-red-600 transition text-sm font-medium"
          >
            Cancel Booking
          </button>
        )}
      </div>

      {/* Rating Section */}
      {booking.status === 'completed' && !booking.rating && (
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Rate This Service</h2>
          <form onSubmit={handleSubmitRating} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Score</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((score) => (
                  <button
                    key={score}
                    type="button"
                    onClick={() => setRatingScore(score)}
                    className={`p-2 rounded-lg transition ${
                      score <= ratingScore ? 'text-yellow-400' : 'text-gray-300'
                    }`}
                  >
                    <FiStar size={28} fill={score <= ratingScore ? 'currentColor' : 'none'} />
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Comment</label>
              <textarea
                value={ratingComment}
                onChange={(e) => setRatingComment(e.target.value)}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Share your experience..."
              />
            </div>
            <button
              type="submit"
              disabled={submitting}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition font-medium disabled:opacity-50"
            >
              {submitting ? 'Submitting...' : 'Submit Rating'}
            </button>
          </form>
        </div>
      )}

      {booking.rating && (
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Your Rating</h2>
          <div className="flex items-center gap-1 mb-2">
            {[1, 2, 3, 4, 5].map((score) => (
              <FiStar
                key={score}
                size={20}
                className={score <= booking.rating.score ? 'text-yellow-400' : 'text-gray-300'}
                fill={score <= booking.rating.score ? 'currentColor' : 'none'}
              />
            ))}
            <span className="ml-2 text-gray-600">({booking.rating.score}/5)</span>
          </div>
          {booking.rating.comment && (
            <p className="text-gray-600 italic">"{booking.rating.comment}"</p>
          )}
        </div>
      )}
    </div>
  );
};

export default BookingDetail;
