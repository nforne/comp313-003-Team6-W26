/**
 * @file customer/NewRequest.jsx
 * @description Page for creating a new service request using the BookingForm component.
 */

import { useNavigate } from 'react-router-dom';
import BookingForm from '../../components/BookingForm';

const NewRequest = () => {
  const navigate = useNavigate();

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold text-gray-800 mb-2">Create New Service Request</h1>
      <p className="text-gray-600 mb-6">
        Fill in the details below to post a new service request. Providers will be able to see
        your request and submit bids.
      </p>

      <div className="bg-white rounded-xl shadow p-6">
        <BookingForm onSuccess={() => navigate('/customer/dashboard')} />
      </div>
    </div>
  );
};

export default NewRequest;
