/**
 * @file ServiceDetail.jsx
 * @description Detailed view of a service request.
 * Shows service info, bids, and allows providers to submit bids
 * or customers to accept bids and create bookings.
 */

import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { getServiceById, submitBid } from '../../api/services.api';
import { createBooking } from '../../api/bookings.api';
import useAuth from '../../hooks/useAuth';
import Loading from '../../components/Loading';
import { FiMapPin, FiClock, FiTag, FiUser, FiDollarSign } from 'react-icons/fi';

const formatDate = (dateStr) => {
  return new Date(dateStr).toLocaleDateString('en-US', {
    year: 'numeric', month: 'long', day: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
};

const ServiceDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [service, setService] = useState(null);
  const [loading, setLoading] = useState(true);
  const [bidPrice, setBidPrice] = useState('');
  const [bidMessage, setBidMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchService();
  }, [id]);

  const fetchService = async () => {
    try {
      const res = await getServiceById(id);
      setService(res.data.data.service);
    } catch (error) {
      toast.error('Failed to load service details.');
      navigate('/services');
    } finally {
      setLoading(false);
    }
  };

  /** Handle bid submission by a provider. */
  const handleSubmitBid = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await submitBid(id, { price: parseFloat(bidPrice), message: bidMessage });
      toast.success('Bid submitted successfully!');
      setBidPrice('');
      setBidMessage('');
      fetchService();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to submit bid.');
    } finally {
      setSubmitting(false);
    }
  };

  /** Handle booking creation by a customer (accepting a bid). */
  const handleAcceptBid = async (bidId) => {
    setSubmitting(true);
    try {
      await createBooking({ serviceId: id, bidId });
      toast.success('Booking confirmed successfully!');
      fetchService();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to create booking.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <Loading />;
  if (!service) return null;

  const isOwner = user && service.customer?._id === user._id;
  const isProvider = user && user.role === 'provider';
  const hasAlreadyBid = isProvider && service.bids?.some((b) => b.provider?._id === user._id);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Service Header */}
      <div className="bg-white rounded-xl shadow-md p-6 mb-6">
        <div className="flex justify-between items-start mb-4">
          <h1 className="text-2xl font-bold text-gray-800">{service.title}</h1>
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
            service.status === 'open' ? 'bg-green-100 text-green-800' :
            service.status === 'in_progress' ? 'bg-yellow-100 text-yellow-800' :
            service.status === 'completed' ? 'bg-blue-100 text-blue-800' :
            'bg-red-100 text-red-800'
          }`}>
            {service.status.replace('_', ' ')}
          </span>
        </div>

        <p className="text-gray-600 mb-6">{service.description}</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2 text-gray-600">
            <FiTag className="text-blue-500" />
            <span className="font-medium">Type:</span>
            <span className="capitalize">{service.serviceType}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <FiMapPin className="text-red-500" />
            <span className="font-medium">Location:</span>
            <span>{service.location}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <FiClock className="text-green-500" />
            <span className="font-medium">Preferred Time:</span>
            <span>{formatDate(service.preferredTime)}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <FiUser className="text-purple-500" />
            <span className="font-medium">Posted by:</span>
            <span>{service.customer?.name}</span>
          </div>
        </div>
      </div>

      {/* Bids Section */}
      <div className="bg-white rounded-xl shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">
          Bids ({service.bids?.length || 0})
        </h2>

        {service.bids?.length === 0 ? (
          <p className="text-gray-500">No bids yet. Be the first to submit a bid!</p>
        ) : (
          <div className="space-y-4">
            {service.bids.map((bid) => (
              <div
                key={bid._id}
                className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-medium text-gray-800">
                      {bid.provider?.name || 'Provider'}
                    </p>
                    <p className="text-sm text-gray-500">{bid.provider?.email}</p>
                    {bid.provider?.bio && (
                      <p className="text-sm text-gray-600 mt-1">{bid.provider.bio}</p>
                    )}
                    {bid.message && (
                      <p className="text-sm text-gray-600 mt-2 italic">"{bid.message}"</p>
                    )}
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-green-600">
                      <FiDollarSign className="inline" />{bid.price}
                    </p>
                    <p className="text-xs text-gray-400">
                      {formatDate(bid.createdAt)}
                    </p>
                  </div>
                </div>

                {/* Accept Bid Button (for service owner only, when status is open) */}
                {isOwner && service.status === 'open' && (
                  <button
                    onClick={() => handleAcceptBid(bid._id)}
                    disabled={submitting}
                    className="mt-3 bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition text-sm font-medium disabled:opacity-50"
                  >
                    {submitting ? 'Processing...' : 'Accept Bid & Book'}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Submit Bid Form (for providers only) */}
      {isProvider && service.status === 'open' && !hasAlreadyBid && (
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Submit Your Bid</h2>
          <form onSubmit={handleSubmitBid} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Your Price ($)
              </label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={bidPrice}
                onChange={(e) => setBidPrice(e.target.value)}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter your bid price"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Message (optional)
              </label>
              <textarea
                value={bidMessage}
                onChange={(e) => setBidMessage(e.target.value)}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Describe your experience and why you're a good fit..."
              />
            </div>
            <button
              type="submit"
              disabled={submitting}
              className="bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition font-medium disabled:opacity-50"
            >
              {submitting ? 'Submitting...' : 'Submit Bid'}
            </button>
          </form>
        </div>
      )}

      {isProvider && hasAlreadyBid && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-blue-700 text-center">
          You have already submitted a bid for this service request.
        </div>
      )}
    </div>
  );
};

export default ServiceDetail;
