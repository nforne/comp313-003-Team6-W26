/**
 * @file Services.jsx
 * @description Public page listing all open service requests.
 * Supports filtering by service type and status.
 */

import { useState, useEffect } from 'react';
import { getServices } from '../../api/services.api';
import ServiceCard from '../../components/ServiceCard';
import Loading from '../../components/Loading';

const SERVICE_TYPES = [
  'all', 'haircut', 'massage', 'cleaning', 'plumbing',
  'electrical', 'tutoring', 'photography', 'catering',
  'landscaping', 'other'
];

const Services = () => {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchServices();
  }, [filter]);

  const fetchServices = async () => {
    setLoading(true);
    try {
      const params = { status: 'open' };
      if (filter !== 'all') params.serviceType = filter;
      const res = await getServices(params);
      setServices(res.data.data.services);
    } catch (error) {
      console.error('Failed to fetch services:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-2">Service Requests</h1>
      <p className="text-gray-600 mb-6">Browse open service requests and submit your bids.</p>

      {/* Filter Bar */}
      <div className="flex flex-wrap gap-2 mb-8">
        {SERVICE_TYPES.map((type) => (
          <button
            key={type}
            onClick={() => setFilter(type)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition ${
              filter === type
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-600 border border-gray-300 hover:bg-gray-50'
            }`}
          >
            {type === 'all' ? 'All' : type.charAt(0).toUpperCase() + type.slice(1)}
          </button>
        ))}
      </div>

      {loading ? (
        <Loading />
      ) : services.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-gray-500 text-lg">No service requests found.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <ServiceCard key={service._id} service={service} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Services;
