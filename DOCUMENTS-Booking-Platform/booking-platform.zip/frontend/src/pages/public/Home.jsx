/**
 * @file Home.jsx
 * @description Landing page for the Booking Platform.
 * Displays hero section, features, and call-to-action.
 */

import { Link } from 'react-router-dom';
import { FiSearch, FiDollarSign, FiCalendar, FiStar } from 'react-icons/fi';

const FEATURES = [
  {
    icon: FiSearch,
    title: 'Find Local Services',
    description: 'Browse and discover local service providers for haircuts, cleaning, plumbing, and more.'
  },
  {
    icon: FiDollarSign,
    title: 'Competitive Bidding',
    description: 'Receive multiple bids from providers and choose the best price and quality for your needs.'
  },
  {
    icon: FiCalendar,
    title: 'Easy Scheduling',
    description: 'Book appointments with automatic calendar updates to prevent scheduling conflicts.'
  },
  {
    icon: FiStar,
    title: 'Ratings & Reviews',
    description: 'Rate providers after service completion and help others make informed decisions.'
  }
];

const Home = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Book Local Services with Confidence
          </h1>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Connect with trusted local service providers, compare bids, and book
            appointments seamlessly through our competitive marketplace.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/services"
              className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition"
            >
              Browse Services
            </Link>
            <Link
              to="/register"
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition"
            >
              Get Started
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">
          How It Works
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {FEATURES.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="text-center p-6 bg-white rounded-xl shadow-md hover:shadow-lg transition"
              >
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon className="text-blue-600" size={28} />
                </div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600 text-sm">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gray-100 py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-gray-600 mb-8">
            Join our platform today as a customer or service provider and experience
            a better way to book local services.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/register"
              className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
            >
              Sign Up as Customer
            </Link>
            <Link
              to="/register"
              className="bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition"
            >
              Join as Provider
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
