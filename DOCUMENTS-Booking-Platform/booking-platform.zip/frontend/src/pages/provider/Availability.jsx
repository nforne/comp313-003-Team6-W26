/**
 * @file provider/Availability.jsx
 * @description Provider availability management page.
 * Allows providers to create, view, and delete availability time slots.
 */

import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { getMyAvailability, createAvailability, deleteAvailability } from '../../api/bookings.api';
import Loading from '../../components/Loading';
import { FiPlus, FiTrash2, FiCalendar } from 'react-icons/fi';

const Availability = () => {
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    date: '',
    startTime: '',
    endTime: ''
  });

  useEffect(() => {
    fetchAvailability();
  }, []);

  const fetchAvailability = async () => {
    try {
      const res = await getMyAvailability();
      setSlots(res.data.data.availability);
    } catch (error) {
      console.error('Failed to fetch availability:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await createAvailability(formData);
      toast.success('Availability slot created!');
      setFormData({ date: '', startTime: '', endTime: '' });
      setShowForm(false);
      fetchAvailability();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to create slot.');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this availability slot?')) return;
    try {
      await deleteAvailability(id);
      toast.success('Slot deleted.');
      fetchAvailability();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to delete slot.');
    }
  };

  if (loading) return <Loading />;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">My Availability</h1>
          <p className="text-gray-600">Manage your available time slots for bookings.</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition"
        >
          <FiPlus /> Add Slot
        </button>
      </div>

      {/* Create Form */}
      {showForm && (
        <div className="bg-white rounded-xl shadow p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">New Availability Slot</h2>
          <form onSubmit={handleCreate} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Start Time</label>
              <input
                type="time"
                value={formData.startTime}
                onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">End Time</label>
              <input
                type="time"
                value={formData.endTime}
                onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>
            <div className="md:col-span-3">
              <button
                type="submit"
                className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition font-medium"
              >
                Create Slot
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Slots List */}
      {slots.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-xl shadow">
          <FiCalendar className="mx-auto text-gray-400 mb-4" size={48} />
          <p className="text-gray-500 text-lg">No availability slots set up yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {slots.map((slot) => (
            <div
              key={slot._id}
              className={`bg-white rounded-xl shadow p-4 border-l-4 ${
                slot.isBlocked ? 'border-red-500' : 'border-green-500'
              }`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium text-gray-800">
                    {new Date(slot.date).toLocaleDateString('en-US', {
                      weekday: 'short', month: 'short', day: 'numeric'
                    })}
                  </p>
                  <p className="text-lg font-semibold text-gray-700">
                    {slot.startTime} - {slot.endTime}
                  </p>
                  {slot.isBlocked && (
                    <span className="text-xs text-red-600 font-medium">Blocked (Booked)</span>
                  )}
                </div>
                {!slot.isBlocked && (
                  <button
                    onClick={() => handleDelete(slot._id)}
                    className="text-red-500 hover:text-red-700 p-1"
                  >
                    <FiTrash2 size={18} />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Availability;
