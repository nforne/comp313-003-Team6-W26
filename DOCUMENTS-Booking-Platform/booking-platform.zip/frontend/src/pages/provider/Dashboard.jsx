/**
 * @file provider/Dashboard.jsx
 * @description Provider dashboard showing overview of bids and bookings.
 */

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';
import { getMyBids } from '../../api/services.api';
import { getMyBookings } from '../../api/bookings.api';
import { FiList, FiCalendar, FiCheckCircle, FiDollarSign } from 'react-icons/fi';

const Dashboard = () => {
  const { user } = useAuth();
  const [bidServices, setBidServices] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [bidsRes, bookRes] = await Promise.all([
          getMyBids(),
          getMyBookings()
        ]);
        setBidServices(bidsRes.data.data.services);
        setBookings(bookRes.data.data.bookings);
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const activeBookings = bookings.filter((b) => b.status === 'confirmed').length;
  const completedBookings = bookings.filter((b) => b.status === 'completed').length;
  const totalEarnings = bookings
    .filter((b) => b.status === 'completed')
    .reduce((sum, b) => sum + b.price, 0);

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-2">
        Welcome back, {user?.name}!
      </h1>
      <p className="text-gray-600 mb-8">Here's your provider dashboard overview.</p>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-xl shadow p-6 border-l-4 border-blue-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Bids</p>
              <p className="text-3xl font-bold text-gray-800">{bidServices.length}</p>
            </div>
            <FiList className="text-blue-500" size={32} />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow p-6 border-l-4 border-green-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Active Bookings</p>
              <p className="text-3xl font-bold text-gray-800">{activeBookings}</p>
            </div>
            <FiCalendar className="text-green-500" size={32} />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow p-6 border-l-4 border-purple-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Completed</p>
              <p className="text-3xl font-bold text-gray-800">{completedBookings}</p>
            </div>
            <FiCheckCircle className="text-purple-500" size={32} />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow p-6 border-l-4 border-yellow-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Earnings</p>
              <p className="text-3xl font-bold text-gray-800">${totalEarnings}</p>
            </div>
            <FiDollarSign className="text-yellow-500" size={32} />
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="flex gap-4 mb-8">
        <Link
          to="/provider/my-services"
          className="flex items-center gap-2 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition font-medium"
        >
          <FiList /> Browse Open Requests
        </Link>
        <Link
          to="/provider/availability"
          className="flex items-center gap-2 bg-white text-gray-700 px-6 py-3 rounded-lg border border-gray-300 hover:bg-gray-50 transition font-medium"
        >
          <FiCalendar /> Manage Availability
        </Link>
      </div>

      {/* Recent Bookings */}
      <div className="bg-white rounded-xl shadow p-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Recent Bookings</h2>
        {bookings.length === 0 ? (
          <p className="text-gray-500">No bookings yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-gray-500 border-b">
                  <th className="pb-3 font-medium">Service</th>
                  <th className="pb-3 font-medium">Customer</th>
                  <th className="pb-3 font-medium">Price</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {bookings.slice(0, 5).map((booking) => (
                  <tr key={booking._id} className="border-b hover:bg-gray-50">
                    <td className="py-3">{booking.service?.title}</td>
                    <td className="py-3">{booking.customer?.name}</td>
                    <td className="py-3 font-medium text-green-600">${booking.price}</td>
                    <td className="py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        booking.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                        booking.status === 'completed' ? 'bg-blue-100 text-blue-800' :
                        booking.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {booking.status}
                      </span>
                    </td>
                    <td className="py-3 text-gray-500">
                      {new Date(booking.scheduledTime).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
