/**
 * @file provider/ProviderBookings.jsx
 * @description Provider's bookings page with ability to complete or cancel bookings.
 */

import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { getMyBookings, updateBookingStatus } from '../../api/bookings.api';
import Loading from '../../components/Loading';

const formatDate = (dateStr) => {
  return new Date(dateStr).toLocaleDateString('en-US', {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
};

const STATUS_COLORS = {
  pending: 'bg-yellow-100 text-yellow-800',
  confirmed: 'bg-green-100 text-green-800',
  completed: 'bg-blue-100 text-blue-800',
  cancelled: 'bg-red-100 text-red-800'
};

const ProviderBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    fetchBookings();
  }, [filter]);

  const fetchBookings = async () => {
    setLoading(true);
    try {
      const params = {};
      if (filter) params.status = filter;
      const res = await getMyBookings(params);
      setBookings(res.data.data.bookings);
    } catch (error) {
      console.error('Failed to fetch bookings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (bookingId, status) => {
    const confirmMsg = status === 'completed'
      ? 'Mark this booking as completed?'
      : 'Cancel this booking?';
    if (!window.confirm(confirmMsg)) return;

    try {
      await updateBookingStatus(bookingId, status);
      toast.success(`Booking ${status} successfully.`);
      fetchBookings();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to update booking.');
    }
  };

  if (loading) return <Loading />;

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">My Bookings</h1>

      {/* Filter */}
      <div className="flex gap-2 mb-6">
        {['', 'confirmed', 'completed', 'cancelled'].map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition ${
              filter === status
                ? 'bg-green-600 text-white'
                : 'bg-white text-gray-600 border border-gray-300 hover:bg-gray-50'
            }`}
          >
            {status === '' ? 'All' : status.charAt(0).toUpperCase() + status.slice(1)}
          </button>
        ))}
      </div>

      {bookings.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-xl shadow">
          <p className="text-gray-500 text-lg">No bookings found.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {bookings.map((booking) => (
            <div key={booking._id} className="bg-white rounded-xl shadow p-6">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">
                    {booking.service?.title || 'Service'}
                  </h3>
                  <p className="text-sm text-gray-500 capitalize">
                    {booking.service?.serviceType} | {booking.service?.location}
                  </p>
                  <p className="text-sm text-gray-600 mt-1">
                    Customer: <span className="font-medium">{booking.customer?.name}</span>
                    {' '}({booking.customer?.email})
                  </p>
                  <p className="text-sm text-gray-600">
                    Scheduled: {formatDate(booking.scheduledTime)}
                  </p>
                  <p className="text-lg font-bold text-green-600 mt-2">
                    ${booking.price}
                  </p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${STATUS_COLORS[booking.status]}`}>
                  {booking.status}
                </span>
              </div>

              {/* Rating display */}
              {booking.rating && (
                <div className="mt-3 p-3 bg-yellow-50 rounded-lg">
                  <p className="text-sm font-medium text-gray-700">
                    Customer Rating: {'★'.repeat(booking.rating.score)}{'☆'.repeat(5 - booking.rating.score)}
                    {' '}({booking.rating.score}/5)
                  </p>
                  {booking.rating.comment && (
                    <p className="text-sm text-gray-600 italic mt-1">"{booking.rating.comment}"</p>
                  )}
                </div>
              )}

              {/* Action Buttons */}
              {booking.status === 'confirmed' && (
                <div className="flex gap-3 mt-4">
                  <button
                    onClick={() => handleStatusUpdate(booking._id, 'completed')}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm font-medium"
                  >
                    Mark as Completed
                  </button>
                  <button
                    onClick={() => handleStatusUpdate(booking._id, 'cancelled')}
                    className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition text-sm font-medium"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ProviderBookings;
